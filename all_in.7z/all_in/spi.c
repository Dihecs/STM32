#include "stm32f10x.h"                         // Заголовок с определениями регистров STM32F103
#include <stdio.h>

// Определения пинов SPI (битбэнг):
#define SPILE_PIN       12                    // PB12 — LE (Latch Enable) или CS для RX5808
#define SPICLK_PIN      13                    // PB13 — CLK (тактирование SPI)
#define SPIDATA_PIN     15                    // PB15 — DATA (бит данных SPI)

// Инициализация GPIO-пинов для SPI-битбэнга

void spi_gpio_init(void)
{
    RCC->APB2ENR |= RCC_APB2ENR_IOPBEN;       // Включаем тактирование порта B
    GPIOB->CRH &= ~((0xF << 16) | (0xF << 20) | (0xF << 28)); // Сбрасываем настройки пинов PB12, PB13, PB15 (по 4 бита на каждый в CRH)
    GPIOB->CRH |=  ((0x2 << 16) | (0x2 << 20) | (0x2 << 28)); // Настраиваем их как выходы push-pull, 2 МГц: MODE=10, CNF=00 → 0b0010 = 0x2
    GPIOB->BSRR = (1 << SPILE_PIN);           // Устанавливаем CS/LE = HIGH (неактивен)
}

// Передача 25-битной команды в RX5808 через SPI-битбэнг (LSB first)

void sendSPICommand_rx5808(uint8_t addr, uint8_t rw, uint32_t data)
{
    // Формируем 25-битную команду: [4 бита адрес | 1 бит RW | 20 бит данных]
    uint32_t cmd = (addr & 0x0F) | ((rw & 1) << 4) | (data << 5);

    GPIOB->BRR  = (1 << SPILE_PIN);           // LE = 0 → начинаем передачу (активный уровень)
    __NOP(); __NOP();                         // Короткая задержка (~1–2 такта)

    for (uint8_t i = 0; i < 25; i++) {        // Передаём 25 бит, начиная с младшего (LSB first)

        if (cmd & 1)                          // Если младший бит = 1
            GPIOB->BSRR = (1 << SPIDATA_PIN); // DATA = 1
        else
            GPIOB->BRR  = (1 << SPIDATA_PIN); // DATA = 0

        GPIOB->BSRR = (1 << SPICLK_PIN);      // CLK ↑ — передаём бит
        __NOP(); __NOP();                     // Задержка (бит читается на фронте)
        GPIOB->BRR  = (1 << SPICLK_PIN);      // CLK ↓ — завершение такта

        cmd >>= 1;                            // Сдвигаем команду вправо → следующий бит
    }

    GPIOB->BSRR = (1 << SPILE_PIN);           // LE = 1 → применить команду
}
