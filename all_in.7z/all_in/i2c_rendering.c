#include "stm32f10x.h"              // CMSIS-заголовок для STM32F103 (регистры, битовые маски)
#include "ssd1306.h"                // Интерфейс для дисплея SSD1306 (I2C)
#include "ssd1306_fonts.h"          // Шрифты для вывода текста на дисплей
#include <stdio.h>                  // Для sprintf()

// Координаты и размеры прямоугольника RSSI на экране
#define RSSI_X          10          // Начальная координата X для полосы RSSI
#define RSSI_Y          45          // Начальная координата Y
#define RSSI_W          98          // Ширина полосы (в пикселях)
#define RSSI_H          10          // Высота полосы (в пикселях)
#define RSSI_MINVAL     91          // Сдвиг, чтобы отрицательные RSSI были видны на экране

// --------------------------------------------------
// Инициализация I2C1 для подключения OLED SSD1306
// --------------------------------------------------
void i2c1_init(void)
{
    RCC->APB1ENR |= RCC_APB1ENR_I2C1EN;       // Включаем тактирование I2C1
    RCC->APB2ENR |= RCC_APB2ENR_IOPBEN;       // Включаем тактирование порта B (PB6, PB7)

    GPIOB->CRL &= ~((0xF << 24) | (0xF << 28)); // Очищаем настройки пинов PB6 и PB7
    GPIOB->CRL |=  ((0xB << 24) | (0xB << 28)); // Настраиваем как AF Open-Drain (CNF=11, MODE=10 → 0xB)

    I2C1->CR1 = I2C_CR1_SWRST;                // Выполняем программный сброс I2C (SWRST = 1)
    I2C1->CR1 = 0;                            // Сбрасываем обратно, чтобы начать конфигурацию

    uint32_t pclk1 = SystemCoreClock / 2;     // Частота шины APB1 = 36 МГц (при SYSCLK = 72 МГц)

    I2C1->CR2 = (pclk1 / 1000000);            // Устанавливаем частоту APB1 в МГц (для I2C тайминга)

    uint16_t ccr = pclk1 / (3 * 400000);      // Расчёт CCR для Fast Mode (400 кГц), duty = 0 (2:1)
    I2C1->CCR = (ccr & 0x0FFF) | I2C_CCR_FS;  // Устанавливаем CCR + Fast Mode флаг (FS=1)

    I2C1->TRISE = (pclk1 / 1000000) * 300 / 1000 + 1; // Устанавливаем TRISE = 300 нс (Fast Mode)

    I2C1->CR1 |= I2C_CR1_PE;                 // Включаем I2C-периферию (PE = 1)
}


// Функция отображения частоты и RSSI на OLED SSD1306

void SFrq_draw(int f, int rssi)
{
    char buf[32];                             // Буфер для вывода строк

    ssd1306_Fill(Black);                      // Очистка экрана (заливка чёрным)

    sprintf(buf, "%d MHz", f);                // Преобразуем частоту в строку, например "5800 MHz"
    ssd1306_SetCursor(0, 5);                  // Устанавливаем курсор в начало строки (X=0, Y=5)
    ssd1306_WriteString(buf, Font_7x10, White); // Печатаем строку белым шрифтом

    sprintf(buf, "RSSI = %d dBm", rssi);      // Формируем строку с RSSI, например "RSSI = -45 dBm"
    ssd1306_SetCursor(0, 20);                 // Курсор ниже, X=0, Y=20
    ssd1306_WriteString(buf, Font_7x10, White);// Печатаем строку RSSI

    ssd1306_DrawRect(RSSI_X, RSSI_Y, RSSI_W, RSSI_H, White); // Рисуем рамку под график RSSI

    int w = rssi + RSSI_MINVAL;               // Смещаем отрицательные RSSI в положительную шкалу
    if (w < 0) w = 0;                          // Ограничиваем минимум
    if (w > RSSI_W) w = RSSI_W;                // Ограничиваем максимум

    ssd1306_FillRect(RSSI_X + 1, RSSI_Y + 1, w, RSSI_H - 2, White); // Рисуем белую полосу шириной w

    ssd1306_UpdateScreen();                   // Отправляем буфер на экран (обновление изображения)
}
