#include "stm32f10x.h"  // Заголовок CMSIS с определением регистров STM32F103
#include <stdio.h>

// Назначения пинов:
#define BUTTON_PIN      10  // PA10 — кнопка (вход)
#define BURST_PIN       4   // PA4  — BURST-импульсы от LM1881 (вход)
#define LED_PIN         12  // PA12 — светодиод (выход)
#define BLINK_PIN       2   // PB2  — моргание при смене частоты (выход)

// Функция инициализации GPIO-портов A и B

void gpio_init(void)
{
    RCC->APB2ENR |= RCC_APB2ENR_IOPAEN | RCC_APB2ENR_IOPBEN; // Включаем тактирование портов GPIOA и GPIOB
    GPIOA->CRH &= ~(0xF << ((BUTTON_PIN - 8) * 4));// Обнуляем биты конфигурации CNF и MODE для PA10
	 // CRH отвечает за пины PA8–PA15 (по 4 бита на каждый)
    GPIOA->CRH |=  (0x8 << ((BUTTON_PIN - 8) * 4)); // Устанавливаем режим "вход с подтяжкой вверх"
		// CNF = 10 (pull-up/pull-down), MODE = 00 (вход)
    GPIOA->ODR |=  (1 << BUTTON_PIN);// Устанавливаем бит в ODR для активации подтяжки вверх (pull-up)
		// Для режима CNF=10, бит ODR управляет подтяжкой: 1 — вверх, 0 — вниз
        
    GPIOA->CRL &= ~(0xF << (BURST_PIN * 4)); // Очищаем биты CNF и MODE для пина PA4
    // Устанавливаем режим "вход с подтяжкой вниз"    
    GPIOA->CRL |=  (0x8 << (BURST_PIN * 4)); // CNF = 10 (pull-up/pull-down), MODE = 00 (вход)   
    GPIOA->ODR &= ~(1 << BURST_PIN); // Обнуляем соответствующий бит ODR для включения подтяжки вниз
    
    GPIOA->CRH &= ~(0xF << ((LED_PIN - 8) * 4)); // Сбрасываем биты CNF и MODE для пина PA12 (в CRH, т.к. пин > 7)        
    GPIOA->CRH |=  (0x2 << ((LED_PIN - 8) * 4)); // Устанавливаем PA12 как push-pull выход на 2 МГц
		// CNF = 00 (обычный выход), MODE = 10 (2 МГц)
    GPIOB->CRL &= ~(0xF << (BLINK_PIN * 4)); // Сбрасываем CNF и MODE для пина PB2 (в CRL — пин <= 7)
    GPIOB->CRL |=  (0x2 << (BLINK_PIN * 4)); // Устанавливаем PB2 как push-pull выход на 2 МГц
    GPIOB->BRR  =  (1 << BLINK_PIN);  // BRR = 1 → установить LOW // Сразу гасим светодиод на PB2 (если он есть)
		// BSRR/BRR — это регистры атомарной установки/сброса пинов
}
