#include "stm32f10x.h"                      // CMSIS-заголовок с регистрами STM32F103
#include <stdio.h>

#define SYSCLK_FREQ     72000000UL          // Заданная системная частота (72 МГц)


// Функция настройки тактирования: HSE → PLL ×9 → SYSCLK = 72 МГц

void clock_config(void)
{
    RCC->CR |= RCC_CR_HSION;               // Включаем внутренний RC-генератор HSI (на всякий случай)

    RCC->CFGR = 0;                         // Сбрасываем конфигурацию делителей/источников тактирования

    RCC->CR &= ~((1 << 16) | (1 << 24));   // Отключаем HSE и PLL перед перенастройкой (бит 16 = HSEON, 24 = PLLON)

    RCC->CIR = 0;                          // Отключаем все прерывания тактирования (если были)

    // --------------------------
    // Настройка внешнего кварца
    // --------------------------
    RCC->CR |= RCC_CR_HSEON;               // Включаем внешний кварц (HSE)

    while (!(RCC->CR & RCC_CR_HSERDY));    // Ждём, пока HSE стабилизируется (HSERDY = 1)

   
    // Настройка FLASH-памяти
    
    FLASH->ACR |= FLASH_ACR_PRFTBE;        // Включаем Prefetch Buffer (ускоряет чтение из FLASH)

    FLASH->ACR &= ~FLASH_ACR_LATENCY;      // Очищаем поле LATENCY (задержка доступа)

    FLASH->ACR |= FLASH_ACR_LATENCY_2;     // Устанавливаем 2 цикла ожидания (нужно при SYSCLK > 48 МГц)

    
    // Делители шин AHB, APB1, APB2
   
    RCC->CFGR |= RCC_CFGR_HPRE_DIV1;       // AHB = SYSCLK / 1 (без делителя)

    RCC->CFGR |= RCC_CFGR_PPRE1_DIV2;      // APB1 = AHB / 2 (макс. 36 МГц для медленной шины)

    RCC->CFGR |= RCC_CFGR_PPRE2_DIV1;      // APB2 = AHB / 1 (без делителя, можно до 72 МГц)

    RCC->CFGR |= RCC_CFGR_ADCPRE_DIV6;     // ADC = PCLK2 / 6 (макс. 12 МГц для ADC → 72/6 = 12 МГц)

    
    // Настройка PLL (×9)
    
    RCC->CFGR |= RCC_CFGR_PLLSRC;          // Источник PLL = HSE (внешний кварц)

    RCC->CFGR |= RCC_CFGR_PLLMULL9;        // Множитель PLL = 9 → 8 МГц * 9 = 72 МГц

    RCC->CR |= RCC_CR_PLLON;               // Включаем PLL

    while (!(RCC->CR & RCC_CR_PLLRDY));    // Ждём, пока PLL станет готов (PLLRDY = 1)

    
    // Переключаем SYSCLK на PLL
    
    RCC->CFGR &= ~RCC_CFGR_SW;             // Очищаем поле выбора источника SYSCLK (SW)

    RCC->CFGR |= RCC_CFGR_SW_PLL;          // Устанавливаем PLL как источник SYSCLK

    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL) {
        // Ждём подтверждения, что PLL выбран как источник SYSCLK
    }

    
    SystemCoreClock = SYSCLK_FREQ; // Обновляем глобальную переменную CMSIS с текущей частотой
}
