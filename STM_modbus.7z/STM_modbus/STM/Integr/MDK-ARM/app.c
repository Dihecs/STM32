#include "main.h"
#include "stm32f1xx_hal.h"
#include "usbd_cdc_if.h"

#include "ssd1306.h"
#include "ssd1306_fonts.h"
#include <stdio.h>
#include <stdint.h>

/* ===== CDC мост (как у тебя, реализован в usbd_cdc_if.c) ===== */
extern int  CDC_Read_Byte(void);
extern void CDC_Send_Byte(uint8_t b);
extern void CDC_Puts(const char *s);


// === PATCH 1: утилиты для логов в USB-CDC ===
#include <stdarg.h>

static void cdc_printf(const char *fmt, ...)
{
    char buf[256];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    if (n < 0) return;
    if (n >= (int)sizeof(buf)) { buf[sizeof(buf)-2] = '\n'; buf[sizeof(buf)-1] = '\0'; }
    CDC_Puts(buf);
}

static void log_pulses_line(const char *prefix, uint32_t pass_no, const uint16_t *dur, int cnt)
{
    // Формат: "<prefix> - 1=XX, 2=YY, 3=ZZ\r\n"
    char line[256];
    int pos = 0;

    if (prefix && prefix[0]) pos += snprintf(line+pos, sizeof(line)-pos, "%s", prefix);
    if (pass_no)             pos += snprintf(line+pos, sizeof(line)-pos, " %lu", (unsigned long)pass_no);
    pos += snprintf(line+pos, sizeof(line)-pos, " - ");

    for (int i = 0; i < cnt; i++) {
        pos += snprintf(line+pos, sizeof(line)-pos, "%d=%u", i+1, (unsigned)dur[i]);
        if (i != cnt-1) pos += snprintf(line+pos, sizeof(line)-pos, ", ");
        if (pos >= (int)sizeof(line)-8) break;
    }
    pos += snprintf(line+pos, sizeof(line)-pos, "\r\n");
    CDC_Puts(line);
}



/* -------------------- Пины/настройки -------------------- */
#define RSSI_CHAN       0               // ADC1_IN0 (PA0)
#define BURST_PIN       4               // PA4 вход BURST
#define BLINK_PIN       2               // PB2 индикатор смены частоты

#define SPILE_PIN       12              // PB12 LE/CS
#define SPICLK_PIN      13              // PB13 CLK
#define SPIDATA_PIN     15              // PB15 MOSI

/* Диапазон и шаг сканирования */
#define FREQ_MIN        4850            // MHz
#define FREQ_MAX        6200            // MHz
#define FREQ_STEP       5               // MHz

/* На всякий случай оставляем твою логику с таблицей и индексами */
#define FREQ_CNT        (((FREQ_MAX - FREQ_MIN) / FREQ_STEP) + 1)

/* -------------------- Глобальные -------------------- */
static volatile uint32_t msTicks;        // если где-то нужен, HAL_GetTick тоже есть
static uint16_t freq_list[FREQ_CNT];     // оставлено
static uint8_t  disp_divider = 0;        // оставлено
#define DISP_EVERY_N_STEPS 10            // оставлено

/* Профили BURST (управление через USB: '1'/'2') */
static volatile uint8_t  sync_target = 5;   // нужно >=5 попаданий из 10
static volatile uint16_t sync_low    = 50;  // окно BURST, мкс
static volatile uint16_t sync_high   = 62;

/* Текущие рабочие переменные */
static int      freq       = 5000;      // ОДНА переменная частоты (как в Arduino)
static int      last_freq  = 5000;
static uint8_t  last_check_fpv = 0;

/* -------------------- Локальные прототипы -------------------- */
static void     tim2_init(void);
static inline void delay_us(uint32_t us);
static void     gpio_init(void);
static void     adc_init(void);
static uint16_t adc_read(void);
static void     i2c1_init(void);
//static void     spi_gpio_init(void);
static uint32_t pulse_width_fast(void);
static int32_t  RSSI_dbmcalc(int raw_adc);
static int      calc_freq_cmd(int f);
static void     precompute_freqs(void);          // оставлено
static inline void sendSPICommand_rx5808(uint8_t addr, uint8_t rw, uint32_t data);
static inline void set_freq_idx(uint16_t idx);   // оставлено (на будущее)
static inline void blink_once(void);
static inline void apply_sync_profile_from_cmd(uint8_t cmd);
static void     SFrq_draw(int f, int rssi, int check_fpv, int pulses);

/* === Упрощённые обёртки под ардуино-логику === */
static inline void set_freq_MHz(int fMHz);
static inline void next_freq_step(void);

/* -------------------- TIM2 + delay_us -------------------- */
static void tim2_init(void)
{
    __HAL_RCC_TIM2_CLK_ENABLE();
    TIM2->PSC = (HAL_RCC_GetHCLKFreq()/1000000UL) - 1; // 1 МГц
    TIM2->ARR = 0xFFFFFFFF;
    TIM2->CNT = 0;
    TIM2->CR1 |= TIM_CR1_CEN;
}

static inline void delay_us(uint32_t us)
{
    uint32_t start = TIM2->CNT;
    while ((uint32_t)(TIM2->CNT - start) < us) { __NOP(); }
}

/* -------------------- GPIO -------------------- */
static void gpio_init(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    /* PA4 = вход BURST (input floating) */
    GPIOA->CRL &= ~(0xF << (BURST_PIN*4));
    GPIOA->CRL |=  (0x4 << (BURST_PIN*4));

    /* PB2 = push-pull 2MHz */
    GPIOB->CRL &= ~(0xF << (BLINK_PIN*4));
    GPIOB->CRL |=  (0x2 << (BLINK_PIN*4));
    GPIOB->BRR   = (1U << BLINK_PIN);

    /* SPI bitbang выводы (PB12, PB13, PB15) */
    GPIOB->CRH &= ~((0xF<<16)|(0xF<<20)|(0xF<<28));
    GPIOB->CRH |=  ((0x3<<16)|(0x3<<20)|(0x3<<28)); // 50МГц PP
    GPIOB->BSRR  = (1U<<SPILE_PIN); // LE=1
}

/* -------------------- ADC -------------------- */
static void adc_init(void)
{
    __HAL_RCC_ADC1_CLK_ENABLE();
    ADC1->CR2 = 0;
    ADC1->SMPR2 = 0;
    ADC1->SQR3 = RSSI_CHAN;
    ADC1->CR2 = ADC_CR2_ADON;
    delay_us(10);
    ADC1->CR2 |= ADC_CR2_RSTCAL; while (ADC1->CR2 & ADC_CR2_RSTCAL) {}
    ADC1->CR2 |= ADC_CR2_CAL;    while (ADC1->CR2 & ADC_CR2_CAL)    {}
}

static uint16_t adc_read(void)
{
    ADC1->CR2 |= ADC_CR2_ADON;
    while (!(ADC1->SR & ADC_SR_EOC)) {}
    return (uint16_t)(ADC1->DR & 0xFFFF);
}

/* -------------------- I2C OLED -------------------- */
static void i2c1_init(void)
{
    __HAL_RCC_I2C1_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    // PB6=SCL, PB7=SDA: AF Open-Drain, 50 МГц
    GPIOB->CRL &= ~((0xF << 24) | (0xF << 28));
    GPIOB->CRL |=  ((0xB << 24) | (0xB << 28));

    I2C1->CR1 = I2C_CR1_SWRST; I2C1->CR1 = 0;

    // PCLK1=36 МГц: CR2=36; 100 кГц (CCR=180), TRISE=37
    I2C1->CR2   = 36;
//    I2C1->CCR   = 180;
//    I2C1->TRISE = 37;
//    I2C1->CR1  |= I2C_CR1_PE;
	
			I2C1->CCR   = I2C_CCR_FS | (0 << I2C_CCR_DUTY_Pos) | 30;
    // TRISE для Fast-mode: TRISE = Fpclk * 300нс + 1 = 36e6*300e-9 + 1 ≈ 11
    I2C1->TRISE = 11;
    I2C1->CR1  |= I2C_CR1_PE;
}

/* -------------------- SPI BitBang для RX5808 -------------------- */
static inline void sendSPICommand_rx5808(uint8_t addr, uint8_t rw, uint32_t data)
{
    // 25 бит LSB-first: [addr4][rw1][data20]
    uint32_t cmd = (addr & 0x0F) | ((rw & 1) << 4) | (data << 5);

    GPIOB->BRR  = (1U<<SPILE_PIN);
    delay_us(3);
    for (uint8_t i=0; i<25; i++) {
        if (cmd & 1) GPIOB->BSRR=(1U<<SPIDATA_PIN);
        else         GPIOB->BRR =(1U<<SPIDATA_PIN);
        GPIOB->BSRR=(1U<<SPICLK_PIN);
        delay_us(3);
        GPIOB->BRR =(1U<<SPICLK_PIN);
        delay_us(3);
        cmd >>= 1;
    }
    delay_us(3);
    GPIOB->BSRR=(1U<<SPILE_PIN);
    delay_us(3);
}

/* -------------------- Измерение BURST -------------------- */
static uint32_t pulse_width_fast(void)
{
    // простая версия: ждем фронт HIGH, меряем длительность HIGH
    uint32_t t0 = TIM2->CNT;
    while (!(GPIOA->IDR & (1U<<BURST_PIN)) && (TIM2->CNT - t0) < 300) { }  // таймаут 300 мкс
    if (!(GPIOA->IDR & (1U<<BURST_PIN))) return 0;

    uint32_t t1 = TIM2->CNT;
    while ( (GPIOA->IDR & (1U<<BURST_PIN)) && (TIM2->CNT - t1) < 300) { }
    return (TIM2->CNT - t1);
}

/* -------------------- RSSI формула -------------------- */
static int32_t RSSI_dbmcalc(int raw_adc)
{
    // твою формулу можно заменить; оставляю примерную калибровку
    return -80 + (raw_adc - 750) / 11;
}

/* -------------------- PLL команда для RX5808 -------------------- */
static int calc_freq_cmd(int fMHz)
{
    int half = (fMHz - 479) / 2;        // (f-479)/2
    int N = (half / 32);
    int A = (half % 32);
    return (N<<7) | (A & 0x1FFF);
}

/* -------------------- Функции, оставленные "как было" -------------------- */
static void precompute_freqs(void)
{
    for (int i=0;i<FREQ_CNT;i++) freq_list[i] = FREQ_MIN + i*FREQ_STEP;
}

/* НЕ используется в новой логике, но оставлено */
static inline void set_freq_idx(uint16_t idx)
{
    int f = freq_list[idx];
    sendSPICommand_rx5808(0x01,1,calc_freq_cmd(f));
    HAL_Delay(3);          // важнее, чем 200 мкс
    (void)adc_read();      // «прожечь» первое чтение
}

/* -------------------- Вспомогательные -------------------- */
static inline void blink_once(void)
{
    GPIOB->BSRR = (1U<<BLINK_PIN);
    __NOP(); __NOP();
    GPIOB->BRR  = (1U<<BLINK_PIN);
}

static inline void apply_sync_profile_from_cmd(uint8_t cmd)
{
    if (cmd == '1') { sync_target = 5; sync_low = 50; sync_high = 62; }
    else if (cmd == '2') { sync_target = 4; sync_low = 45; sync_high = 62; }
}

/* -------------------- OLED отрисовка -------------------- */
static void SFrq_draw (int f, int rssi, int check_fpv, int pulses)
{
    char buf[32];
    ssd1306_Fill(Black);

    sprintf(buf,"%d MHz", f);
    ssd1306_SetCursor(0,5);
    ssd1306_WriteString(buf, Font_7x10, White);

    sprintf(buf,"RSSI = %d dBm", rssi);
    ssd1306_SetCursor(0,20);
    ssd1306_WriteString(buf, Font_7x10, White);

    sprintf(buf,"Num_fpv = %d/10", pulses);
    ssd1306_SetCursor(0,35);
    ssd1306_WriteString(buf, Font_7x10, White);

    ssd1306_UpdateScreen();
}

/* -------------------- Упрощённые обёртки (Arduino-логика) -------------------- */
static inline void set_freq_MHz(int fMHz)
{
    // Перестройка на частоту в МГц
    sendSPICommand_rx5808(0x01, 1, calc_freq_cmd(fMHz));
    HAL_Delay(5);           // дать PLL устояться (3–5 мс)
    (void)adc_read();       // прожечь первое чтение АЦП
}

static inline void next_freq_step(void)
{
    freq += FREQ_STEP;
    if (freq > FREQ_MAX) freq = FREQ_MIN;
}

/* -------------------- App_Init/App_Loop -------------------- */
void App_Init(void)
{
    HAL_Delay(50);
    tim2_init();
		gpio_init();
    adc_init();
    i2c1_init();
    ssd1306_Init();
   //spi_gpio_init();
   // precompute_freqs();   // оставлено (на всякий случай)

    // стартовая частота как в Arduino-скетче
    freq = 5000;
    set_freq_MHz(freq);

    ssd1306_Fill(Black);
    ssd1306_SetCursor(0,0);
    ssd1306_WriteString("USB OK", Font_7x10, White);
    ssd1306_UpdateScreen();
}

void App_Loop(void)
{
    static int prev_rssi = -999;

    // мигание индикатором
//    static uint32_t t_led = 0;
//    if ((int32_t)(HAL_GetTick() - t_led) >= 50) {
//        GPIOB->ODR ^= (1U<<BLINK_PIN);
//        t_led += 50;
//    }

    /* Команды профиля по USB ('1'/'2') */
    int ch = CDC_Read_Byte();
    if (ch == '1' || ch == '2') {
        apply_sync_profile_from_cmd((uint8_t)ch);
        CDC_Send_Byte((uint8_t)ch);
    }

    /* === Перестройка и выдержка PLL === */
    set_freq_MHz(freq);
    //blink_once();
		
    /* === RSSI и отрисовка (ВНИМАНИЕ: строго freq, без +10!) === */
    int rssi = RSSI_dbmcalc(adc_read());
    if (prev_rssi == -999 || (rssi - prev_rssi > 2) || (prev_rssi - rssi > 2)) {
        SFrq_draw(freq, rssi, 0, last_check_fpv);
        prev_rssi = rssi;
    }

    /* === BURST: 10 проверок, засчитываем окно профиля, без "22..30" === */
    int check_fpv = 0;
		static uint32_t pass_no = 0;           // счётчик проходов по частоте
		uint16_t dur_list[10];                 // сюда пишем длительности
		int dur_cnt = 0;
    for (int i = 0; i < 10; i++) {
        uint32_t dur = pulse_width_fast();
			 if (dur > 0 && dur < 300 && dur_cnt < 10) {
        dur_list[dur_cnt++] = (uint16_t)dur;
				}
       if ((dur >= sync_low && dur <= sync_high) || (dur >22 && dur<30)) {
            check_fpv++;

            if (check_fpv >= sync_target) break;   // 5 из 10 по умолчанию
        }
    }
    last_check_fpv = (uint8_t)check_fpv;
		pass_no++;
		//log_pulses_line("Prohodik", pass_no, dur_list, dur_cnt);
    /* === Удержание, если нашли (без «двойного шага» после HOLD) === */
    if (check_fpv >= sync_target) {
			
			
			set_freq_MHz(freq);
			HAL_Delay(3);         // чуть длиннее, чем обычная задержка (надёжнее)
			(void)adc_read();     // прожечь первое чтение

			int confirm_hits = 0;
			for (int i = 0; i < 10; i++) {
					uint32_t dur2 = pulse_width_fast();
					if ((dur2 >= sync_low && dur2 <= sync_high) || (dur2 >22 && dur2<30)) {
							confirm_hits++;
							if (confirm_hits >= sync_target) break;  // 5 из 10 для подтверждения
								}
			}

			// Если подтверждение не удалось — пропускаем частоту
			if (confirm_hits < sync_target) {
					next_freq_step();   // шаг дальше по диапазону
					return;
				}
			{	    /* --- HILL-CLIMB: локальный поиск пика RSSI вокруг подтверждённой частоты --- */
       int best_freq = freq;
       int best_rssi = -999;

       for (int df = -10; df <= 10; df += 2) {      // окно ±10 МГц, шаг 2 МГц
           int ftest = freq + df;
           if (ftest < FREQ_MIN || ftest > FREQ_MAX) continue;

           set_freq_MHz(ftest);
           HAL_Delay(3);           // дать PLL устояться
           (void)adc_read();       // прожечь первое чтение
           int rssi_now = RSSI_dbmcalc(adc_read());

           if (rssi_now > best_rssi) {
               best_rssi = rssi_now;
               best_freq = ftest;
            }
        }
	
        // перейти на частоту с максимальным RSSI
        freq = best_freq;
        set_freq_MHz(freq);
        HAL_Delay(3);
        (void)adc_read();
			}
    /* --- END HILL-CLIMB --- */

			  uint16_t dur_hold[12];
        int    cnt_hold = 0;
        // небольшой тайм-бокс, чтобы не тормозить: ~12 измерений
        for (int i = 0; i < 12; i++) {
            uint32_t d = pulse_width_fast();
            if (d > 0 && d < 300 && cnt_hold < 12) dur_hold[cnt_hold++] = (uint16_t)d;
        }
        //log_pulses_line("Stood", 0, dur_hold, cnt_hold);
				
        uint32_t t0 = HAL_GetTick();
        uint32_t next_draw = HAL_GetTick();

        while ((int32_t)(HAL_GetTick() - t0) < 1500) {
            int ch2 = CDC_Read_Byte();
            if (ch2 == '1' || ch2 == '2') {
                apply_sync_profile_from_cmd((uint8_t)ch2);
                CDC_Send_Byte((uint8_t)ch2);
            }
            if ((int32_t)(HAL_GetTick() - next_draw) >= 100) {
                int rssi_hold = RSSI_dbmcalc(adc_read());
                SFrq_draw(freq, rssi_hold, check_fpv, last_check_fpv);
                prev_rssi  = rssi_hold;
                next_draw += 100;
            }
        }

        // продолжить со следующего шага (ровно +5 МГц), без лишнего инкремента idx
        next_freq_step();
        return;
    }

    /* Если не нашли — обычный шаг по кругу */
   next_freq_step();
}
