#ifndef APP_H_
#define APP_H_

#ifdef __cplusplus
extern "C" {
#endif

void App_Init(void);
void App_Loop(void);
#ifdef __cplusplus
}
#endif
#endif
