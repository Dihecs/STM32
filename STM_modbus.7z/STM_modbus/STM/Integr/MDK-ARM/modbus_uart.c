#include "modbus_uart.h"
#include <string.h>

/* ===== ????????? RTU/?????? ===== */
#define MB_BITS_PER_CHAR  11.0f
#define RX_BUF_SZ         256

volatile uint16_t MB_HR[MB_HR_COUNT] = {0};
static   uint16_t _HR_prev[MB_HR_COUNT] = {0};

static volatile uint8_t  _rx_buf[RX_BUF_SZ];
static volatile uint16_t _rx_len = 0;
static volatile uint32_t _last_byte_us = 0;

static uint32_t _Tchar_us = 0, _T1_5_us = 0, _T3_5_us = 0;

/* ===== ????????? ===== */
static uint16_t _mb_crc16(const uint8_t *p, uint16_t n);
static void     _send_uart(const uint8_t *p, uint16_t n);
static void     _mb_exception(uint8_t addr, uint8_t func, uint8_t code);
static void     _on_registers_written(uint16_t start, uint16_t count, bool bc);

static void     _fn03_read_holding(const uint8_t *frm, uint16_t len);
static void     _fn06_write_single (const uint8_t *frm, uint16_t len);
static void     _fn10_write_multi  (const uint8_t *frm, uint16_t len);

/* ===== Weak-??? ???????????? ===== */
__attribute__((weak)) void MB_OnWrite(uint16_t index, uint16_t value) {
    /* ?? ?????????: HR[0] ????????? ?????? ?? MB_LED_Pin */
    if (index == 0) {
        __HAL_RCC_GPIOB_CLK_ENABLE(); // ?? ?????? ?????? (Port ????? ???? ?????? � ????? ? .h)
        if (value == 0) HAL_GPIO_WritePin(MB_LED_GPIO_Port, MB_LED_Pin, GPIO_PIN_RESET);
        else if (value == 1) HAL_GPIO_WritePin(MB_LED_GPIO_Port, MB_LED_Pin, GPIO_PIN_SET);
        else if (value == 2) HAL_GPIO_TogglePin(MB_LED_GPIO_Port, MB_LED_Pin);
    }
}

/* ===== ????????????? USART1: PA9(TX), PA10(RX) ===== */
void MB_UART_Init(void)
{
    __HAL_RCC_AFIO_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_USART1_CLK_ENABLE();

    /* ????????? ????? USART1 (????? PA9/PA10) */
    AFIO->MAPR &= ~(AFIO_MAPR_USART1_REMAP);

    /* PA9 = TX: AF Push-Pull 50MHz */
    GPIOA->CRH &= ~(0xF << ((9-8)*4));
    GPIOA->CRH |=  (0xB << ((9-8)*4));

    /* PA10 = RX: Floating input */
    GPIOA->CRH &= ~(0xF << ((10-8)*4));
    GPIOA->CRH |=  (0x4 << ((10-8)*4));

#ifdef MB_RS485_DE_Port
    /* DE-??? ??? push-pull, ?? ????????? 0 (?????) */
    if (MB_RS485_DE_Port == GPIOA) __HAL_RCC_GPIOA_CLK_ENABLE();
    if (MB_RS485_DE_Port == GPIOB) __HAL_RCC_GPIOB_CLK_ENABLE();
    if (MB_RS485_DE_Port == GPIOC) __HAL_RCC_GPIOC_CLK_ENABLE();
    HAL_GPIO_WritePin(MB_RS485_DE_Port, MB_RS485_DE_Pin, GPIO_PIN_RESET);
    GPIO_InitTypeDef g = {0};
    g.Pin = MB_RS485_DE_Pin; g.Mode = GPIO_MODE_OUTPUT_PP; g.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(MB_RS485_DE_Port, &g);
#endif

    /* ??????? */
    uint32_t pclk2 = HAL_RCC_GetPCLK2Freq();                // ?????? 72MHz
    USART1->BRR = (uint16_t)((pclk2 + (MB_BAUD/2)) / MB_BAUD);

    /* 8N1 + RXNEIE */
    USART1->CR1 = USART_CR1_TE | USART_CR1_RE | USART_CR1_RXNEIE;
    USART1->CR2 = 0;
    USART1->CR3 = 0;
    USART1->CR1 |= USART_CR1_UE;

    /* NVIC */
    HAL_NVIC_SetPriority(USART1_IRQn, 3, 0);
    HAL_NVIC_EnableIRQ(USART1_IRQn);

    /* ???????? RTU */
    _Tchar_us = (uint32_t)((MB_BITS_PER_CHAR * 1e6f) / (float)MB_BAUD + 0.5f);
    _T1_5_us  = (uint32_t)(1.5f * (float)_Tchar_us);
    _T3_5_us  = (uint32_t)(3.5f * (float)_Tchar_us);

    /* ????????????? ????? */
    _rx_len = 0;
    _last_byte_us = TIM2->CNT;   // ???? TIM2 ??? ?????? (tim2_init() ?????? ???? ?????? ?? MB_UART_Init)
    for (uint16_t i=0;i<MB_HR_COUNT;i++) _HR_prev[i] = MB_HR[i];
}

/* ===== IRQ: ??????? ?? USART1_IRQHandler() ===== */
void Modbus_UART1_IRQHandler(void)
{
    uint32_t sr = USART1->SR;

    /* ????? ?????? */
    if (sr & (USART_SR_ORE | USART_SR_FE | USART_SR_NE)) {
        volatile uint32_t tmp = USART1->DR; (void)tmp;
    }

    if (sr & USART_SR_RXNE) {
        uint8_t b = (uint8_t)USART1->DR;  // ?????? DR ?????????? RXNE
        if (_rx_len < RX_BUF_SZ) _rx_buf[_rx_len++] = b;
        _last_byte_us = TIM2->CNT;        // micros(): 1 ??? = 1 ???
    }
}

/* ===== ???????? ===== */
static void _send_uart(const uint8_t *p, uint16_t n)
{
#ifdef MB_RS485_DE_Port
    HAL_GPIO_WritePin(MB_RS485_DE_Port, MB_RS485_DE_Pin, GPIO_PIN_SET);   // DE=1
#endif
    for (uint16_t i=0; i<n; i++) {
        while (!(USART1->SR & USART_SR_TXE)) {}
        USART1->DR = p[i];
    }
    while (!(USART1->SR & USART_SR_TC)) {}

#ifdef MB_RS485_DE_Port
    HAL_GPIO_WritePin(MB_RS485_DE_Port, MB_RS485_DE_Pin, GPIO_PIN_RESET); // DE=0
#endif
}

/* ===== CRC16 (Modbus) ===== */
static uint16_t _mb_crc16(const uint8_t *p, uint16_t n)
{
    uint16_t crc = 0xFFFF;
    for (uint16_t i=0;i<n;i++) {
        crc ^= p[i];
        for (uint8_t b=0;b<8;b++)
            crc = (crc & 1) ? (uint16_t)((crc>>1) ^ 0xA001) : (uint16_t)(crc>>1);
    }
    return crc;
}

/* ===== Exception ===== */
static void _mb_exception(uint8_t addr, uint8_t func, uint8_t code)
{
    uint8_t resp[5];
    resp[0]=addr; resp[1]=(uint8_t)(func|0x80); resp[2]=code;
    uint16_t crc=_mb_crc16(resp,3);
    resp[3]=(uint8_t)(crc & 0xFF);
    resp[4]=(uint8_t)(crc >> 8);
    _send_uart(resp,5);
}

/* ===== ??????? Poll: ?????????? ?????? ????? =====
   ?????? ?????? �????????? ?????????�: ?? ????? ??????????? RX
   ????????? ?????? ?????????? RXNE (?? ?????????), ????? ?? ????????
   ???????? ??????? ????? ? ???????? ??????. */
void MB_Poll(void)
{
    /* ???? ?? ?????? ?????? */
    if (_rx_len == 0) return;

    /* ???? ????? ????? ????? = 3.5T */
    uint32_t silent = (uint32_t)(TIM2->CNT - _last_byte_us);
    if (!(silent >= _T3_5_us || silent >= 2000)) return;
    /* --- ?????????? ?? ????? ??????????? --- */
    uint32_t cr1_save = USART1->CR1;
    USART1->CR1 &= ~USART_CR1_RXNEIE;    // ????????? RXNE IRQ ?? ????? ???????????

    uint16_t len = _rx_len;
    if (len > RX_BUF_SZ) len = RX_BUF_SZ;

    uint8_t frm[RX_BUF_SZ];
    memcpy(frm, (const void*)_rx_buf, len);
    _rx_len = 0;                         // ?????????? RX ?????

    USART1->CR1 = cr1_save;              // ??????? RXNEIE
    /* --- ????? ?????????? --- */

    if (len < 4) return;

    uint16_t rx_crc = (uint16_t)(frm[len-2] | ((uint16_t)frm[len-1] << 8));
    uint16_t calc   = _mb_crc16(frm, (uint16_t)(len-2));
    if (rx_crc != calc) return;

    uint8_t addr = frm[0];
    if (addr != MB_SLAVE_ADDR && addr != 0x00) return;

    uint8_t func = frm[1];
    if      (func == 0x03) _fn03_read_holding(frm, len);
    else if (func == 0x06) _fn06_write_single (frm, len);
    else if (func == 0x10) _fn10_write_multi  (frm, len);
    else                   _mb_exception(addr, func, 0x01);
}

/* ===== Callback ????? ?????? ===== */
static void _on_registers_written(uint16_t start, uint16_t count, bool bc)
{
    for (uint16_t i=0;i<count;i++) {
        uint16_t idx = (uint16_t)(start + i);
        if (idx >= MB_HR_COUNT) break;

        if (MB_HR[idx] != _HR_prev[idx]) {
            _HR_prev[idx] = MB_HR[idx];
            MB_OnWrite(idx, MB_HR[idx]);  // ???????????????? ???
        }
    }
    (void)bc;
}

/* ===== 0x03 Read Holding Registers ===== */
static void _fn03_read_holding(const uint8_t *frm, uint16_t len)
{
    if (len < 8) return;
    uint8_t  addr  = frm[0];
    uint16_t start = (uint16_t)(frm[2]<<8) | frm[3];
    uint16_t qty   = (uint16_t)(frm[4]<<8) | frm[5];
    if (qty==0 || qty>125 || (start+qty)>MB_HR_COUNT) { _mb_exception(addr,0x03,0x02); return; }

    uint8_t resp[5 + 2*125];
    resp[0]=addr; resp[1]=0x03; resp[2]=(uint8_t)(2*qty);
    for (uint16_t i=0;i<qty;i++){
        uint16_t v = MB_HR[start+i];
        resp[3+2*i]   = (uint8_t)(v>>8);
        resp[3+2*i+1] = (uint8_t)(v & 0xFF);
    }
    uint16_t sz=(uint16_t)(3+2*qty);
    uint16_t crc=_mb_crc16(resp,sz);
    resp[sz]  =(uint8_t)(crc & 0xFF);
    resp[sz+1]=(uint8_t)(crc>>8);
    _send_uart(resp,(uint16_t)(sz+2));
}

/* ===== 0x06 Write Single Register ===== */
static void _fn06_write_single(const uint8_t *frm, uint16_t len)
{
    if (len < 8) { _mb_exception(frm[0],0x06,0x03); return; }
    uint8_t  addr = frm[0];
    uint16_t reg  = (uint16_t)(frm[2]<<8) | frm[3];
    uint16_t val  = (uint16_t)(frm[4]<<8) | frm[5];
    if (reg >= MB_HR_COUNT) { _mb_exception(addr,0x06,0x02); return; }

    bool bc = (addr == 0x00);
    MB_HR[reg] = val;
    _on_registers_written(reg,1,bc);

    if (!bc) {
        uint8_t resp[8];
        memcpy(resp, frm, 6);
        uint16_t crc=_mb_crc16(resp,6);
        resp[6]=(uint8_t)(crc & 0xFF);
        resp[7]=(uint8_t)(crc>>8);
        _send_uart(resp,8);
    }
}

/* ===== 0x10 Write Multiple Registers ===== */
static void _fn10_write_multi(const uint8_t *frm, uint16_t len)
{
    if (len < 9) return;
    uint8_t  addr  = frm[0];
    uint16_t start = (uint16_t)(frm[2]<<8) | frm[3];
    uint16_t qty   = (uint16_t)(frm[4]<<8) | frm[5];
    uint8_t  bc    = frm[6];

    if (qty==0 || qty>125 || (start+qty)>MB_HR_COUNT || bc != qty*2) { _mb_exception(addr,0x10,0x02); return; }
    if (len < (uint16_t)(9 + bc)) { _mb_exception(addr,0x10,0x03); return; }

    for (uint16_t i=0;i<qty;i++) {
        uint16_t v = (uint16_t)((frm[7+2*i]<<8) | frm[7+2*i+1]);
        MB_HR[start+i] = v;
    }
    _on_registers_written(start, qty, (addr==0x00));

    uint8_t resp[8];
    resp[0]=addr; resp[1]=0x10;
    resp[2]=(uint8_t)(start>>8); resp[3]=(uint8_t)start;
    resp[4]=(uint8_t)(qty>>8);   resp[5]=(uint8_t)qty;
    uint16_t crc=_mb_crc16(resp,6);
    resp[6]=(uint8_t)(crc & 0xFF);
    resp[7]=(uint8_t)(crc>>8);
    _send_uart(resp,8);
}
