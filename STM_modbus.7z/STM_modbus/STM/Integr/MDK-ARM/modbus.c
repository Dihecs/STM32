#include "modebus_cdc.h"
#include "main.h"
#include "usbd_cdc_if.h"
#include <string.h>
#include <stdbool.h>

/* ---------- ????????? ?????? ---------- */
#define MB_BITS_PER_CHAR   11.0f      /* ????? + 8??? + (????????) + ???? */
#define RX_BUF_SZ          256        /* ??????? CDC-????? */


#define MB_COILS_COUNT   64
#define MB_DI_COUNT      64
#define MB_IR_COUNT      64

static uint8_t  MB_COILS[(MB_COILS_COUNT+7)/8];  // R/W ????
static uint8_t  MB_DI   [(MB_DI_COUNT+7)/8];     // R/O ????
static uint16_t MB_IR[MB_IR_COUNT];              // R/O ?????

static inline uint8_t _bit_get(const uint8_t *m, uint16_t i) {
    return (m[i>>3] >> (i & 7)) & 1u;
}
static inline void _bit_set(uint8_t *m, uint16_t i, uint8_t v) {
    uint8_t mask = (uint8_t)(1u << (i & 7));
    if (v) m[i>>3] |= mask; else m[i>>3] &= (uint8_t)~mask;
}


/* ????? USB-?????? (???????? ? MB_CDC_Receive) */
static volatile uint8_t  _usb_packet_edge = 0;

/* ???????? (holding) */
volatile uint16_t MB_HR[MB_HR_COUNT] = {0};
static   uint16_t _HR_prev[MB_HR_COUNT] = {0};

/* ??????? ????? CDC */
static uint8_t  _rx_buf[RX_BUF_SZ];
static volatile uint16_t _rx_len = 0;
static volatile uint32_t _last_byte_us = 0;

/* ???????? RTU */
static uint32_t _Tchar_us = 0;
static uint32_t _T1_5_us  = 0;
static uint32_t _T3_5_us  = 0;

/* --------- GPIO LED (???????????) --------- */
static inline void _led_on(void){   HAL_GPIO_WritePin(MB_LED_GPIO_PORT, MB_LED_GPIO_PIN, GPIO_PIN_SET); }
static inline void _led_off(void){  HAL_GPIO_WritePin(MB_LED_GPIO_PORT, MB_LED_GPIO_PIN, GPIO_PIN_RESET); }
static inline void _led_toggle(void){ HAL_GPIO_TogglePin(MB_LED_GPIO_PORT, MB_LED_GPIO_PIN); }

/* ---------- ????????? ---------- */
static uint16_t _mb_crc16(const uint8_t *data, uint16_t len);
static void     _send_cdc(const uint8_t *p, uint16_t n);
static void     _mb_exception(uint8_t addr, uint8_t func, uint8_t code);
static void     _fn03_read_holding(const uint8_t *frm, uint16_t len);
static void     _fn06_write_single (const uint8_t *frm, uint16_t len);
static void     _fn10_write_multi  (const uint8_t *frm, uint16_t len);
static void     _on_registers_written(uint16_t start, uint16_t count, bool is_broadcast);

static void     _fn01_read_coils      (const uint8_t *frm, uint16_t len);
static void     _fn02_read_discrete   (const uint8_t *frm, uint16_t len);
static void     _fn04_read_input_regs (const uint8_t *frm, uint16_t len);
static void     _fn05_write_single    (const uint8_t *frm, uint16_t len);
static void     _fn0F_write_multiple  (const uint8_t *frm, uint16_t len);


/* ---------- CRC16 Modbus (poly 0xA001), ????? LSB?MSB ---------- */
static uint16_t _mb_crc16(const uint8_t *data, uint16_t len)
{
    uint16_t crc = 0xFFFF;
    for (uint16_t i = 0; i < len; ++i) {
        crc ^= data[i];
        for (uint8_t b = 0; b < 8; ++b) {
            crc = (crc & 1) ? (uint16_t)((crc >> 1) ^ 0xA001) : (uint16_t)(crc >> 1);
        }
    }
    return crc;
}

/* ---------- ???????? ?????? ---------- */
static void _send_cdc(const uint8_t *p, uint16_t n)
{
    while (CDC_Transmit_FS((uint8_t*)p, n) == USBD_BUSY) { __NOP(); }
}

/* ---------- Exception ---------- */
static void _mb_exception(uint8_t addr, uint8_t func, uint8_t code)
{
    uint8_t resp[5];
    resp[0] = addr;
    resp[1] = (uint8_t)(func | 0x80);
    resp[2] = code;
    uint16_t crc = _mb_crc16(resp, 3);
    resp[3] = (uint8_t)(crc & 0xFF);  /* LSB */
    resp[4] = (uint8_t)(crc >> 8);    /* MSB */
    _send_cdc(resp, 5);
}

/* ---------- ??????? ?? CDC_Receive_FS() ---------- */
uint8_t MB_CDC_Receive(uint8_t* Buf, uint32_t *Len)
{
    uint32_t now = micros();
    if (*Len) {
        uint32_t free = RX_BUF_SZ - _rx_len;
        uint32_t copy = (*Len <= free) ? *Len : free;
        if (copy) {
            memcpy(&_rx_buf[_rx_len], Buf, copy);
            _rx_len += (uint16_t)copy;
        }
        _last_byte_us    = now;
        _usb_packet_edge = 1;   /* ??????? ????? USB-?????? */
    }
    return (uint8_t)USBD_OK;
}

/* ---------- ????????????? ---------- */
void MB_Init(void)
{
    /* LED (???? ?? ????? � ????? ??????? ???? ????) */
    __HAL_RCC_GPIOB_CLK_ENABLE();
    GPIO_InitTypeDef g = {0};
    g.Pin = MB_LED_GPIO_PIN;
    g.Mode = GPIO_MODE_OUTPUT_PP;
    g.Pull = GPIO_NOPULL;
    g.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(MB_LED_GPIO_PORT, &g);
    _led_off();

    /* ???????? RTU: MB_BAUD ?????? ????????? ? ?????????? ? ??????? */
    _Tchar_us = (uint32_t)((MB_BITS_PER_CHAR * 1e6f) / (float)MB_BAUD + 0.5f);
    _T1_5_us  = (uint32_t)(1.5f * (float)_Tchar_us);
    _T3_5_us  = (uint32_t)(3.5f * (float)_Tchar_us);

    _rx_len = 0;
    _last_byte_us = micros();

    for (uint16_t i = 0; i < MB_HR_COUNT; ++i) _HR_prev[i] = MB_HR[i];
}

/* ---------- ??????? ???????? ---------- */
void MB_Poll(void)
{
    uint16_t len = _rx_len;
    if (len == 0) return;

    uint32_t silent = (uint32_t)(micros() - _last_byte_us);

    /* ????? ?????: 3.5T ??? ???? USB-?????? + ?????? = 2500 ??? */
    if (!((silent >= _T3_5_us) || (_usb_packet_edge && silent >= 2500))) return;
    _usb_packet_edge = 0;

    /* ????????? ????? ????? ? ????????? ????? */
    if (len > RX_BUF_SZ) len = RX_BUF_SZ;
    uint8_t frm[RX_BUF_SZ];
    memcpy(frm, _rx_buf, len);

    /* ??????? ????? ????? ??? ????????? ???? */
    _rx_len = 0;

    if (len < 4) return;

    uint16_t rx_crc = (uint16_t)(frm[len - 2] | ((uint16_t)frm[len - 1] << 8));
    uint16_t calc   = _mb_crc16(frm, (uint16_t)(len - 2));
    if (rx_crc != calc) return;

    uint8_t addr = frm[0];
    if (addr != MB_SLAVE_ADDR && addr != 0x00 /*broadcast*/) return;

    uint8_t func = frm[1];
		if      (func == 0x01) _fn01_read_coils(frm, len);
else if (func == 0x02) _fn02_read_discrete(frm, len);
else if (func == 0x03) _fn03_read_holding(frm, len);
else if (func == 0x04) _fn04_read_input_regs(frm, len);
else if (func == 0x05) _fn05_write_single(frm, len);
else if (func == 0x06) _fn06_write_single(frm, len);
else if (func == 0x0F) _fn0F_write_multiple(frm, len);
else if (func == 0x10) _fn10_write_multi(frm, len);
    else                   _mb_exception(addr, func, 0x01); /* ILLEGAL FUNCTION */
}

/* ---------- Callback ?? ?????? ????????? ---------- */
static void _on_registers_written(uint16_t start, uint16_t count, bool is_broadcast)
{
    for (uint16_t i = 0; i < count; ++i) {
        uint16_t idx = (uint16_t)(start + i);
        if (idx >= MB_HR_COUNT) break;

        if (MB_HR[idx] != _HR_prev[idx]) {
            /* ??????: HR[0] ????????? LED (????? ??????) */
            if (idx == 0) {
                uint16_t v = MB_HR[0];
                if      (v == 0) _led_off();
                else if (v == 1) _led_on();
                else if (v == 2) _led_toggle();
            }
            _HR_prev[idx] = MB_HR[idx];
        }
    }
    (void)is_broadcast;
}
/* ---------- 0x01 Read Coils ---------- */
static void _fn01_read_coils(const uint8_t *frm, uint16_t len)
{
    if (len < 8) return;
    uint8_t  addr  = frm[0];
    uint16_t start = (frm[2]<<8) | frm[3];
    uint16_t qty   = (frm[4]<<8) | frm[5];
    if (qty==0 || (start+qty)>MB_COILS_COUNT || qty>2000) { _mb_exception(addr,0x01,0x02); return; }

    uint16_t nbytes = (uint16_t)((qty + 7) >> 3);
    uint8_t resp[3 + 250 + 2];      // ?? 2000 ??? => 250 ????
    resp[0]=addr; resp[1]=0x01; resp[2]=(uint8_t)nbytes;

    for (uint16_t b=0; b<nbytes; ++b) {
        uint8_t v=0;
        for (uint8_t k=0;k<8;k++) {
            uint16_t i = (uint16_t)(start + b*8 + k);
            if (i < start+qty && _bit_get(MB_COILS, i)) v |= (uint8_t)(1u<<k); // LSB-first
        }
        resp[3+b]=v;
    }
    uint16_t sz= (uint16_t)(3+nbytes);
    uint16_t crc=_mb_crc16(resp, sz);
    resp[sz]= (uint8_t)(crc & 0xFF);
    resp[sz+1]=(uint8_t)(crc >> 8);
    _send_cdc(resp, (uint16_t)(sz+2));
}
/* ---------- 0x02 Read Discrete inputs---------- */
static void _fn02_read_discrete(const uint8_t *frm, uint16_t len)
{
    if (len < 8) return;
    uint8_t  addr  = frm[0];
    uint16_t start = (frm[2]<<8) | frm[3];
    uint16_t qty   = (frm[4]<<8) | frm[5];
    if (qty==0 || (start+qty)>MB_DI_COUNT || qty>2000) { _mb_exception(addr,0x02,0x02); return; }

    uint16_t nbytes=(uint16_t)((qty+7)>>3);
    uint8_t resp[3 + 250 + 2];
    resp[0]=addr; resp[1]=0x02; resp[2]=(uint8_t)nbytes;

    for (uint16_t b=0;b<nbytes;++b){
        uint8_t v=0;
        for (uint8_t k=0;k<8;k++){
            uint16_t i=(uint16_t)(start+b*8+k);
            if (i<start+qty && _bit_get(MB_DI,i)) v|=(uint8_t)(1u<<k);
        }
        resp[3+b]=v;
    }
    uint16_t sz=(uint16_t)(3+nbytes);
    uint16_t crc=_mb_crc16(resp,sz);
    resp[sz]= (uint8_t)(crc & 0xFF);
    resp[sz+1]=(uint8_t)(crc >> 8);
    _send_cdc(resp,(uint16_t)(sz+2));
}

/* ---------- 0x04 Read Input Registers ---------- */
static void _fn04_read_input_regs(const uint8_t *frm, uint16_t len)
{
    if (len < 8) return;
    uint8_t  addr  = frm[0];
    uint16_t start = (frm[2]<<8) | frm[3];
    uint16_t qty   = (frm[4]<<8) | frm[5];
    if (qty==0 || (start+qty)>MB_IR_COUNT || qty>125){ _mb_exception(addr,0x04,0x02); return; }

    uint8_t resp[5 + 2*125];
    resp[0]=addr; resp[1]=0x04; resp[2]=(uint8_t)(2*qty);
    for (uint16_t i=0;i<qty;i++){
        uint16_t v=MB_IR[start+i];
        resp[3+2*i]   =(uint8_t)(v>>8);
        resp[3+2*i+1]=(uint8_t)(v & 0xFF);
    }
    uint16_t sz=(uint16_t)(3+2*qty);
    uint16_t crc=_mb_crc16(resp,sz);
    resp[sz]=(uint8_t)(crc & 0xFF);
    resp[sz+1]=(uint8_t)(crc >> 8);
    _send_cdc(resp,(uint16_t)(sz+2));
}

static void _fn05_write_single(const uint8_t *frm, uint16_t len)
{
    if (len < 8) return;
    uint8_t  addr=frm[0];
    uint16_t bit =(frm[2]<<8) | frm[3];
    uint16_t val =(frm[4]<<8) | frm[5];    // 0xFF00=ON, 0x0000=OFF
    if (bit >= MB_COILS_COUNT){ _mb_exception(addr,0x05,0x02); return; }
    if (!(val==0xFF00 || val==0x0000)){ _mb_exception(addr,0x05,0x03); return; }

    _bit_set(MB_COILS, bit, (val==0xFF00));

    uint8_t resp[8];                   // ???-? ????? ????? ?????? 6 ???? + CRC
    memcpy(resp, frm, 6);
    uint16_t crc=_mb_crc16(resp,6);
    resp[6]=(uint8_t)(crc & 0xFF);
    resp[7]=(uint8_t)(crc >> 8);
    _send_cdc(resp,8);
}

void _fn0F_write_multiple(const uint8_t *frm, uint16_t len)
{
    if (len < 9) return;
    uint8_t  addr  = frm[0];
    uint16_t start = (frm[2]<<8) | frm[3];
    uint16_t qty   = (frm[4]<<8) | frm[5];
    uint8_t  bc    = frm[6];

    uint16_t need = (uint16_t)((qty + 7) >> 3);   // ??????? ???? ?????? ?????? ??????
    if (qty==0 || qty>2000 || (start+qty)>MB_COILS_COUNT || bc != need){ _mb_exception(addr,0x0F,0x03); return; }
    if (len < (uint16_t)(9 + bc)) { _mb_exception(addr,0x0F,0x03); return; }

    // ?????????? LSB-first
    for (uint16_t i=0;i<qty;i++){
        uint8_t byte = frm[7 + (i>>3)];
        uint8_t bit  = (uint8_t)((byte >> (i & 7)) & 1u);
        _bit_set(MB_COILS, (uint16_t)(start + i), bit);
    }

    // ?????: addr,0x0F,start,qty + CRC
    uint8_t resp[8];
    resp[0]=addr; resp[1]=0x0F;
    resp[2]=(uint8_t)(start>>8); resp[3]=(uint8_t)start;
    resp[4]=(uint8_t)(qty>>8);   resp[5]=(uint8_t)qty;
    uint16_t crc=_mb_crc16(resp,6);
    resp[6]=(uint8_t)(crc & 0xFF);
    resp[7]=(uint8_t)(crc >> 8);
    _send_cdc(resp,8);
}

/* ---------- 0x03 Read Holding Registers ---------- */
static void _fn03_read_holding(const uint8_t *frm, uint16_t len)
{
    if (len < 8) return;
    uint8_t  addr  = frm[0];
    uint16_t start = (uint16_t)(frm[2] << 8) | frm[3];
    uint16_t qty   = (uint16_t)(frm[4] << 8) | frm[5];

    if (qty == 0 || (start + qty) > MB_HR_COUNT) { _mb_exception(addr, 0x03, 0x02); return; }

    uint8_t resp[5 + 2*32];                  /* ????????? qty ?? 32 */
    resp[0] = addr;
    resp[1] = 0x03;
    resp[2] = (uint8_t)(2 * qty);

    for (uint16_t i = 0; i < qty; ++i) {
        uint16_t v = MB_HR[start + i];
        resp[3 + 2*i]     = (uint8_t)(v >> 8);
        resp[3 + 2*i + 1] = (uint8_t)(v & 0xFF);
    }

    uint16_t sz  = (uint16_t)(3 + 2*qty);
    uint16_t crc = _mb_crc16(resp, sz);
    resp[sz]   = (uint8_t)(crc & 0xFF);   /* LSB */
    resp[sz+1] = (uint8_t)(crc >> 8);     /* MSB */
    _send_cdc(resp, (uint16_t)(sz + 2));
}

/* ---------- 0x06 Write Single Register ---------- */
static void _fn06_write_single(const uint8_t *frm, uint16_t len)
{
    if (len < 8) { _mb_exception(frm[0], 0x06, 0x03); return; }

    uint8_t  addr = frm[0];
    uint16_t reg  = (uint16_t)(frm[2] << 8) | frm[3];
    uint16_t val  = (uint16_t)(frm[4] << 8) | frm[5];

    if (reg >= MB_HR_COUNT) { _mb_exception(addr, 0x06, 0x02); return; }

    bool broadcast = (addr == 0x00);
    MB_HR[reg] = val;
    _on_registers_written(reg, 1, broadcast);

    if (!broadcast) {
        uint8_t resp[8];
        resp[0] = addr;
        resp[1] = 0x06;
        resp[2] = (uint8_t)(reg >> 8);
        resp[3] = (uint8_t) reg;
        resp[4] = (uint8_t)(val >> 8);
        resp[5] = (uint8_t) val;
        uint16_t crc = _mb_crc16(resp, 6);
        resp[6] = (uint8_t)(crc & 0xFF);  /* LSB */
        resp[7] = (uint8_t)(crc >> 8);    /* MSB */
        _send_cdc(resp, 8);
    }
}

/* ---------- 0x10 Write Multiple Registers ---------- */
static void _fn10_write_multi(const uint8_t *frm, uint16_t len)
{
    if (len < 9) return;

    uint8_t  addr  = frm[0];
    uint16_t start = (uint16_t)(frm[2] << 8) | frm[3];
    uint16_t qty   = (uint16_t)(frm[4] << 8) | frm[5];
    uint8_t  bc    = frm[6];

    if (qty == 0 || (start + qty) > MB_HR_COUNT || bc != qty * 2) { _mb_exception(addr, 0x10, 0x02); return; }
    if (len < (uint16_t)(9 + bc)) { _mb_exception(addr, 0x10, 0x03); return; }

    bool broadcast = (addr == 0x00);
    for (uint16_t i = 0; i < qty; ++i) {
        uint16_t v = (uint16_t)((frm[7 + 2*i] << 8) | frm[7 + 2*i + 1]);  /* BE ? ??????? */
        MB_HR[start + i] = v;
    }
    _on_registers_written(start, qty, broadcast);

    if (!broadcast) {
        uint8_t resp[8];
        resp[0] = addr;  resp[1] = 0x10;
        resp[2] = (uint8_t)(start >> 8);
        resp[3] = (uint8_t) start;
        resp[4] = (uint8_t)(qty   >> 8);
        resp[5] = (uint8_t) qty;
        uint16_t crc = _mb_crc16(resp, 6);
        resp[6] = (uint8_t)(crc & 0xFF);  /* LSB */
        resp[7] = (uint8_t)(crc >> 8);    /* MSB */
        _send_cdc(resp, 8);
    }
}
