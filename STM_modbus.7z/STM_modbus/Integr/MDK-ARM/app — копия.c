#include "main.h"              // тянет HAL/MCU заголовки
#include "ssd1306.h"
#include "ssd1306_fonts.h"
#include <stdio.h>
#include <stdint.h>
#include "usbd_cdc_if.h"
#include "stm32f1xx_hal.h"
/* ===== USB CDC мост (у тебя уже есть в usbd_cdc_if.c) ===== */
extern int  CDC_Read_Byte(void);
extern void CDC_Send_Byte(uint8_t b);
extern void CDC_Puts(const char *s);

/* -------------------- Константы -------------------- */
#define SYSCLK_FREQ     72000000UL
#define RSSI_CHAN       0
#define BURST_PIN       4
#define BLINK_PIN       2

#define SPILE_PIN       12
#define SPICLK_PIN      13
#define SPIDATA_PIN     15

#define FREQ_MIN        4850
#define FREQ_MAX        6200
#define FREQ_STEP       5
#define FREQ_CNT        (((FREQ_MAX - FREQ_MIN) / FREQ_STEP) + 1)

#define ABS(x)          ((x) < 0 ? -(x) : (x))

/* -------------------- Глобальные -------------------- */
static int last_freq = 5000;
static int freq      = 5000;

static uint16_t freq_list[FREQ_CNT];
static uint8_t  disp_divider = 0;
#define DISP_EVERY_N_STEPS 1

/* --- профиль BURST --- */
static volatile uint8_t  sync_target = 5;
static volatile uint16_t sync_low    = 50;
static volatile uint16_t sync_high   = 62;

/* -------------------- Прототипы локальных -------------------- */
static void tim2_init(void);
static inline void delay_us(uint32_t us);
static void gpio_init(void);
static void adc_init(void);
static uint16_t adc_read(void);
static void i2c1_init(void);
static void spi_gpio_init(void);
static uint32_t pulse_width_fast(void);
static int32_t RSSI_dbmcalc(int raw_adc);
static int calc_freq_cmd(int f);
static void precompute_freqs(void);
static inline void sendSPICommand_rx5808(uint8_t addr, uint8_t rw, uint32_t data);
static inline void set_freq_idx(uint16_t idx);
static inline void blink_once(void);
static inline void apply_sync_profile_from_cmd(uint8_t cmd);
static void SFrq_draw(int f, int rssi, int check_fpv, int pulses);

/* -------------------- TIM2 + delay_us -------------------- */
static void tim2_init(void)
{
    __HAL_RCC_TIM2_CLK_ENABLE();
    TIM2->PSC = (SystemCoreClock / 1000000) - 1;
    TIM2->ARR = 0xFFFFFFFF;
    TIM2->CNT = 0;
    TIM2->CR1 |= TIM_CR1_CEN;
}

static inline void delay_us(uint32_t us)
{
    uint32_t start = TIM2->CNT;
    while ((uint32_t)(TIM2->CNT - start) < us) { }
}

/* -------------------- GPIO -------------------- */
static void gpio_init(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    /* PA4 — вход BURST (инпут со встроенным pull-down не используем, как было) */
    GPIOA->CRL &= ~(0xF << (BURST_PIN*4));
    GPIOA->CRL |=  (0x8 << (BURST_PIN*4));
    GPIOA->ODR &= ~(1 << BURST_PIN);

    /* PB2 — индикатор */
    GPIOB->CRL &= ~(0xF << (BLINK_PIN*4));
    GPIOB->CRL |=  (0x2 << (BLINK_PIN*4));  // push-pull 2 MHz
    GPIOB->BRR  =  (1 << BLINK_PIN);
}

/* -------------------- ADC -------------------- */
static void adc_init(void)
{
    __HAL_RCC_ADC1_CLK_ENABLE();
    ADC1->SMPR2 = 0;
    ADC1->SQR3  = RSSI_CHAN;

    ADC1->CR2 = ADC_CR2_ADON;
    HAL_Delay(1);
    ADC1->CR2 |= ADC_CR2_RSTCAL;   while (ADC1->CR2 & ADC_CR2_RSTCAL) {}
    ADC1->CR2 |= ADC_CR2_CAL;      while (ADC1->CR2 & ADC_CR2_CAL) {}
}

static uint16_t adc_read(void)
{
    ADC1->CR2 |= ADC_CR2_ADON;
    while (!(ADC1->SR & ADC_SR_EOC)) {}
    return (uint16_t)(ADC1->DR & 0xFFFF);
}

/* -------------------- I2C OLED -------------------- */
void i2c1_init(void)
{
    /* тактирование портов/периферии */
    RCC->APB2ENR |= RCC_APB2ENR_IOPBEN;
    RCC->APB1ENR |= RCC_APB1ENR_I2C1EN;

    /* PB6=SCL, PB7=SDA: AF Open-Drain, 50 МГц */
    GPIOB->CRL &= ~((0xF << 24) | (0xF << 28));
    GPIOB->CRL |=  ((0xB << 24) | (0xB << 28));

    /* полноценный сброс модуля */
    I2C1->CR1 = I2C_CR1_SWRST;
    I2C1->CR1 = 0;

    /* PCLK1 = 36 МГц → CR2 = 36 */
    I2C1->CR2 = 36;

    /* 100 кГц: CCR = 180, TRISE = 37 (AN2824) */
    I2C1->CCR   = 180;         // стандартный режим
    I2C1->TRISE = 37;

    I2C1->CR1  |= I2C_CR1_PE;
}


/* -------------------- SPI BitBang для RX5808 -------------------- */
static void spi_gpio_init(void)
{
    __HAL_RCC_GPIOB_CLK_ENABLE();
    GPIOB->CRH &= ~((0xF<<16)|(0xF<<20)|(0xF<<28));
    GPIOB->CRH |=  ((0x3<<16)|(0x3<<20)|(0x3<<28)); // PB12/13/15: 50 МГц push-pull
    GPIOB->BSRR = (1<<SPILE_PIN);
}

static inline void sendSPICommand_rx5808(uint8_t addr, uint8_t rw, uint32_t data)
{
    uint32_t cmd = (addr&0x0F) | ((rw&1)<<4) | (data<<5);
    GPIOB->BRR  = (1<<SPILE_PIN);
    delay_us(5);
    for(uint8_t i=0;i<25;i++) {
        (cmd & 1) ? (GPIOB->BSRR=(1<<SPIDATA_PIN)) : (GPIOB->BRR =(1<<SPIDATA_PIN));
        GPIOB->BSRR=(1<<SPICLK_PIN); delay_us(5);
        GPIOB->BRR =(1<<SPICLK_PIN); delay_us(5);
        cmd >>= 1;
    }
    delay_us(5);
    GPIOB->BSRR=(1<<SPILE_PIN);
    delay_us(5);
}

/* -------------------- Измерение BURST -------------------- */
static uint32_t pulse_width_fast(void)
{
    uint32_t t0 = TIM2->CNT;
    while((GPIOA->IDR&(1<<BURST_PIN)) && ((uint32_t)(TIM2->CNT-t0)<300));
    t0 = TIM2->CNT;
    while(!(GPIOA->IDR&(1<<BURST_PIN)) && ((uint32_t)(TIM2->CNT-t0)<300));
    if(!(GPIOA->IDR&(1<<BURST_PIN))) return 0;
    uint32_t t1 = TIM2->CNT;
    while((GPIOA->IDR&(1<<BURST_PIN)) && ((uint32_t)(TIM2->CNT-t1)<300));
    return (uint32_t)(TIM2->CNT - t1);
}

static int32_t RSSI_dbmcalc(int raw_adc)
{
    return -80 + (raw_adc - 750) / 11;
}

/* -------------------- Преобразование и предвычисление -------------------- */
static int calc_freq_cmd(int f)
{
    int N = ((f-479)/2)/32;
    int A = ((f-479)/2)%32;
    return (N<<7)|(A&0x1FFF);
}

static void precompute_freqs(void)
{
    for(int i=0;i<FREQ_CNT;i++) freq_list[i] = FREQ_MIN + i*FREQ_STEP;
}

static inline void set_freq_idx(uint16_t idx)
{
    freq = freq_list[idx];
    sendSPICommand_rx5808(0x01,1,calc_freq_cmd(freq));
    delay_us(200);
}

static inline void blink_once(void)
{
    GPIOB->BSRR = (1<<BLINK_PIN);
    __NOP(); __NOP();
    GPIOB->BRR  = (1<<BLINK_PIN);
}

static inline void apply_sync_profile_from_cmd(uint8_t cmd)
{
    if (cmd == '1') { sync_target = 5; sync_low = 50; sync_high = 62; }
    else if (cmd == '2') { sync_target = 4; sync_low = 45; sync_high = 62; }
}

/* -------------------- Отрисовка экрана -------------------- */
static void SFrq_draw(int f,int rssi, int check_fpv, int pulses)
{
    char buf[32];
    ssd1306_Fill(Black);
    sprintf(buf,"%d MHz",f);
    ssd1306_SetCursor(0,5);  ssd1306_WriteString(buf,Font_7x10,White);
    sprintf(buf,"RSSI = %d dBm",rssi);
    ssd1306_SetCursor(0,20); ssd1306_WriteString(buf,Font_7x10,White);
    sprintf(buf,"Num_fpv = %d ",check_fpv);
    ssd1306_SetCursor(0,35); ssd1306_WriteString(buf,Font_7x10,White);
    ssd1306_SetCursor(0,50);
    sprintf(buf, "SYNC: %u/10", pulses);
    ssd1306_WriteString(buf, Font_7x10, White);
    ssd1306_UpdateScreen();
}

/* =========================== ПУБЛИЧНЫЕ ФУНКЦИИ =========================== */

void App_Init(void)
{
    /* Счётчики SysTick уже настроены HAL (HAL_Init) — берём HAL_Delay/HAL_GetTick */

    tim2_init();
    gpio_init();
    adc_init();
    i2c1_init();
		HAL_Delay(15);
    ssd1306_Init();	
    spi_gpio_init();

    precompute_freqs();

    int start_idx = (5000 - FREQ_MIN)/FREQ_STEP;
    if(start_idx<0) start_idx=0;
    if(start_idx>=FREQ_CNT) start_idx=0;
    set_freq_idx((uint16_t)start_idx);
    GPIOB->BRR=(1<<BLINK_PIN);
}

//void App_Loop(void)
//{
//static uint32_t t_led = 0;
//	uint32_t now = HAL_GetTick();
//	if ((int32_t)(now - t_led) >= 1000) {
//    GPIOB->ODR ^= (1<<BLINK_PIN);
//    t_led = now;
//}
//    static int prev_rssi = -999;
//    static uint16_t idx = 0;
//    static uint8_t last_check_fpv = 0;

//    /* --- читаем команды --- */
//static uint32_t next_tick = 0;

//if ((int32_t)(now - next_tick) >= 0) {
//    CDC_Puts("TICK\r\n");
//    next_tick = now + 1000;
//}

//// Эхо:
//int ch = CDC_Read_Byte();
//if (ch >= 0) {
//    CDC_Send_Byte((uint8_t)ch);
//}



//    int check_fpv = 0;

//    idx++; if(idx>=FREQ_CNT) idx=0;
//    set_freq_idx(idx);
//    blink_once();

//    int rssi = RSSI_dbmcalc(adc_read());
//    if(disp_divider++>=DISP_EVERY_N_STEPS || ABS(rssi-prev_rssi)>2)
//    {
//        SFrq_draw(freq+10, rssi, check_fpv, last_check_fpv);
//        prev_rssi = rssi;
//        disp_divider = 0;
//    }

//    /* --- BURST по активному профилю --- */
//    for(int i=0;i<10;i++)
//    {
//        uint32_t dur = pulse_width_fast();
//        if((dur >= sync_low && dur <= sync_high) || (dur >22 && dur<30)) check_fpv++;
//        if (check_fpv >= sync_target) break;
//    }
//    last_check_fpv = (uint8_t)check_fpv;

//    /* --- удержание --- */
//    if (check_fpv > 4){
//        uint32_t t0 = HAL_GetTick();
//        SFrq_draw(freq, rssi, check_fpv, last_check_fpv);
//        prev_rssi   = rssi;
//        disp_divider = 0;

//        uint32_t next_draw = HAL_GetTick();
//        while ((int32_t)(HAL_GetTick() - t0) < 1500)
//        {
//            int ch2 = CDC_Read_Byte();
//            if (ch2 == '1' || ch2 == '2') {
//                apply_sync_profile_from_cmd((uint8_t)ch2);
//                CDC_Send_Byte((uint8_t)ch2);
//            }

//            if ((int32_t)(HAL_GetTick() - next_draw) >= 100) {
//                int rssi_hold = RSSI_dbmcalc(adc_read());
//                SFrq_draw(freq, rssi_hold, check_fpv, last_check_fpv);
//                prev_rssi  = rssi_hold;
//                next_draw += 100;
//            }
//        }

//        idx++; if (idx >= FREQ_CNT) idx = 0;
//        set_freq_idx(idx);
//        blink_once();
//    }
//}

//void App_Loop(void)
//{
//    static uint32_t t_led = 0, t_tick = 0;

//    // 1) мигаем PB2 каждые 250 мс — видно ли, что МК крутит цикл?
//    if ((int32_t)(HAL_GetTick() - t_led) >= 250) {
//        GPIOB->ODR ^= (1U<<2); // BLINK_PIN = PB2
//        t_led += 250;
//    }

//    // 2) раз в секунду шлем "TICK" по CDC
//    if ((int32_t)(HAL_GetTick() - t_tick) >= 1000) {
//        CDC_Puts("TICK\r\n");
//        t_tick += 1000;
//    }

//    // 3) простое эхо
//    int ch = CDC_Read_Byte();
//    if (ch >= 0) CDC_Send_Byte((uint8_t)ch);
//}

void App_Loop(void)
{
    static volatile uint32_t spin = 0;
    if (++spin >= 200000) {        // подбери число, чтобы моргало ~2–4 раза в сек
        GPIOB->ODR ^= (1U<<2);     // PB2
        spin = 0;
    }

    // А дальше — как было:
    static uint32_t t_tick = 0;
    if ((int32_t)(HAL_GetTick() - t_tick) >= 1000) {
        CDC_Puts("TICK\r\n");
        t_tick += 1000;
    }

    int ch = CDC_Read_Byte();
    if (ch >= 0) CDC_Send_Byte((uint8_t)ch);
}
