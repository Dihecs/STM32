#include "main.h"
#include "stm32f1xx_hal.h"
#include "usbd_cdc_if.h"

#include "ssd1306.h"
#include "ssd1306_fonts.h"
#include <stdio.h>
#include <stdint.h>

/* ===== CDC мост (реализован у тебя в usbd_cdc_if.c) ===== */
extern int  CDC_Read_Byte(void);
extern void CDC_Send_Byte(uint8_t b);
extern void CDC_Puts(const char *s);

/* -------------------- Пины/настройки -------------------- */
#define RSSI_CHAN       0               // ADC1_IN0 (PA0) — как у тебя
#define BURST_PIN       4               // PA4 вход BURST
#define BLINK_PIN       2               // PB2 светодиод

#define SPILE_PIN       12              // PB12 (LE)
#define SPICLK_PIN      13              // PB13 (CLK)
#define SPIDATA_PIN     15              // PB15 (DATA)

#define FREQ_MIN        4850
#define FREQ_MAX        6200
#define FREQ_STEP       5
#define FREQ_CNT        (((FREQ_MAX - FREQ_MIN) / FREQ_STEP) + 1)

#define ABS(x)          ((x) < 0 ? -(x) : (x))

/* -------------------- Глобальные -------------------- */
static int last_freq = 5000;
static int freq      = 5000;

static uint16_t freq_list[FREQ_CNT];
static uint8_t  disp_divider = 0;
#define DISP_EVERY_N_STEPS 10

/* --- профиль BURST --- */
static volatile uint8_t  sync_target = 5;
static volatile uint16_t sync_low    = 50;
static volatile uint16_t sync_high   = 62;

/* -------------------- Локальные прототипы -------------------- */
static void tim2_init(void);
static inline void delay_us(uint32_t us);
static void gpio_init(void);
static void adc_init(void);
static uint16_t adc_read(void);
static void i2c1_init(void);
static void spi_gpio_init(void);
static uint32_t pulse_width_fast(void);
static int32_t RSSI_dbmcalc(int raw_adc);
static int calc_freq_cmd(int f);
static void precompute_freqs(void);
static inline void sendSPICommand_rx5808(uint8_t addr, uint8_t rw, uint32_t data);
static inline void set_freq_idx(uint16_t idx);
static inline void blink_once(void);
static inline void apply_sync_profile_from_cmd(uint8_t cmd);
static void SFrq_draw(int f, int rssi, int check_fpv, int pulses);

/* -------------------- TIM2 + delay_us -------------------- */
static void tim2_init(void)
{
    __HAL_RCC_TIM2_CLK_ENABLE();
    TIM2->PSC = (SystemCoreClock / 1000000) - 1;  // 1 МГц
    TIM2->ARR = 0xFFFFFFFF;
    TIM2->CNT = 0;
    TIM2->CR1 |= TIM_CR1_CEN;
}

static inline void delay_us(uint32_t us)
{
    uint32_t start = TIM2->CNT;
    while ((uint32_t)(TIM2->CNT - start) < us) { }
}

/* -------------------- GPIO -------------------- */
static void gpio_init(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    // PA4 = вход BURST (floating input)
    GPIOA->CRL &= ~(0xF << (BURST_PIN*4));
    GPIOA->CRL |=  (0x8 << (BURST_PIN*4));
    GPIOA->ODR &= ~(1U << BURST_PIN);

    // PB2 = светодиод (2 МГц, push-pull)
    GPIOB->CRL &= ~(0xF << (BLINK_PIN*4));
    GPIOB->CRL |=  (0x2 << (BLINK_PIN*4));
    GPIOB->BRR  =  (1U << BLINK_PIN);
}

/* -------------------- ADC -------------------- */
static void adc_init(void)
{
    __HAL_RCC_ADC1_CLK_ENABLE();
    // Самый простой режим: один канал, минимальные семплы
    ADC1->SMPR2 = 0;
    ADC1->SQR3  = RSSI_CHAN;

    ADC1->CR2 = ADC_CR2_ADON;
    HAL_Delay(1);
    ADC1->CR2 |= ADC_CR2_RSTCAL;   while (ADC1->CR2 & ADC_CR2_RSTCAL) {}
    ADC1->CR2 |= ADC_CR2_CAL;      while (ADC1->CR2 & ADC_CR2_CAL) {}
}

static uint16_t adc_read(void)
{
    ADC1->CR2 |= ADC_CR2_ADON;
    while (!(ADC1->SR & ADC_SR_EOC)) {}
    return (uint16_t)(ADC1->DR & 0xFFFF);
}

/* -------------------- I2C1 (PB6/PB7) -------------------- */
static void i2c1_init(void)
{
    // тактирование
    RCC->APB2ENR |= RCC_APB2ENR_IOPBEN;
    RCC->APB1ENR |= RCC_APB1ENR_I2C1EN;

    // PB6=SCL, PB7=SDA: AF Open-Drain, 50 МГц
    GPIOB->CRL &= ~((0xF << 24) | (0xF << 28));
    GPIOB->CRL |=  ((0xB << 24) | (0xB << 28));

    // сброс модуля
    I2C1->CR1 = I2C_CR1_SWRST;
    I2C1->CR1 = 0;

    // PCLK1=36 МГц -> CR2=36; 100 кГц: CCR=180; TRISE=37
    I2C1->CR2   = 36;
//    I2C1->CCR   = 180;
//    I2C1->TRISE = 37;
//    uint32_t pclk1 = SystemCoreClock/2;
//    I2C1->CR2 = (pclk1/1000000);
//    uint16_t ccr = pclk1/(3*400000);
//    I2C1->CCR = (ccr&0x0FFF)|I2C_CCR_FS;
//    I2C1->TRISE = (pclk1/1000000)*300/1000 +1;

		I2C1->CCR   = I2C_CCR_FS | (0 << I2C_CCR_DUTY_Pos) | 30;
    // TRISE для Fast-mode: TRISE = Fpclk * 300нс + 1 = 36e6*300e-9 + 1 ≈ 11
    I2C1->TRISE = 11;
    I2C1->CR1  |= I2C_CR1_PE;
}

/* -------------------- SPI BitBang для RX5808 -------------------- */
static void spi_gpio_init(void)
{
    __HAL_RCC_GPIOB_CLK_ENABLE();
    // PB12/13/15: 50 МГц push-pull
    GPIOB->CRH &= ~((0xF<<16)|(0xF<<20)|(0xF<<28));
    GPIOB->CRH |=  ((0x3<<16)|(0x3<<20)|(0x3<<28));
    GPIOB->BSRR = (1<<SPILE_PIN); // LE = 1
}

static inline void sendSPICommand_rx5808(uint8_t addr, uint8_t rw, uint32_t data)
{
    uint32_t cmd = (addr&0x0F) | ((rw&1)<<4) | (data<<5);
    GPIOB->BRR  = (1<<SPILE_PIN);
    delay_us(5);
    for(uint8_t i=0;i<25;i++) {
        (cmd & 1) ? (GPIOB->BSRR=(1<<SPIDATA_PIN)) : (GPIOB->BRR =(1<<SPIDATA_PIN));
        GPIOB->BSRR=(1<<SPICLK_PIN); delay_us(5);
        GPIOB->BRR =(1<<SPICLK_PIN); delay_us(5);
        cmd >>= 1;
    }
    delay_us(5);
    GPIOB->BSRR=(1<<SPILE_PIN);
    delay_us(5);
}

/* -------------------- BURST измерение -------------------- */
static uint32_t pulse_width_fast(void)
{
    uint32_t t0 = TIM2->CNT;
    while((GPIOA->IDR&(1<<BURST_PIN)) && ((uint32_t)(TIM2->CNT-t0)<300));
    t0 = TIM2->CNT;
    while(!(GPIOA->IDR&(1<<BURST_PIN)) && ((uint32_t)(TIM2->CNT-t0)<300));
    if(!(GPIOA->IDR&(1<<BURST_PIN))) return 0;
    uint32_t t1 = TIM2->CNT;
    while((GPIOA->IDR&(1<<BURST_PIN)) && ((uint32_t)(TIM2->CNT-t1)<300));
    return (uint32_t)(TIM2->CNT - t1);
}

static int32_t RSSI_dbmcalc(int raw_adc)
{
    return -80 + (raw_adc - 750) / 11;
}

/* -------------------- Частоты -------------------- */
static int calc_freq_cmd(int f)
{
    int N = ((f-479)/2)/32;
    int A = ((f-479)/2)%32;
    return (N<<7)|(A&0x1FFF);
}

static void precompute_freqs(void)
{
    for(int i=0;i<FREQ_CNT;i++) freq_list[i] = FREQ_MIN + i*FREQ_STEP;
}

static inline void set_freq_idx(uint16_t idx)
{
    freq = freq_list[idx];
    sendSPICommand_rx5808(0x01,1,calc_freq_cmd(freq));
    delay_us(200);
		HAL_Delay(3);
		(void)adc_read();  
}

static inline void blink_once(void)
{
    GPIOB->BSRR = (1<<BLINK_PIN);
    __NOP(); __NOP();
    GPIOB->BRR  = (1<<BLINK_PIN);
}

static inline void apply_sync_profile_from_cmd(uint8_t cmd)
{
    if (cmd == '1') { sync_target = 5; sync_low = 50; sync_high = 62; }
    else if (cmd == '2') { sync_target = 4; sync_low = 45; sync_high = 62; }
}

/* -------------------- Отрисовка -------------------- */
static void SFrq_draw(int f,int rssi, int check_fpv, int pulses)
{
    char buf[32];
    ssd1306_Fill(Black);
    sprintf(buf,"%d MHz",f);
    ssd1306_SetCursor(0,5);  ssd1306_WriteString(buf,Font_7x10,White);
    sprintf(buf,"RSSI = %d dBm",rssi);
    ssd1306_SetCursor(0,20); ssd1306_WriteString(buf,Font_7x10,White);
    sprintf(buf,"Num_fpv = %d ",check_fpv);
    ssd1306_SetCursor(0,35); ssd1306_WriteString(buf,Font_7x10,White);
    ssd1306_SetCursor(0,50);
    sprintf(buf, "SYNC: %u/10", pulses);
    ssd1306_WriteString(buf, Font_7x10, White);
    ssd1306_UpdateScreen();
}

/* =========================== ПУБЛИЧНО =========================== */

void App_Init(void)
{
    tim2_init();
    gpio_init();
    adc_init();
    i2c1_init();
    HAL_Delay(15);          // дать I2C1 проснуться
    ssd1306_Init();         // теперь безопасно
    spi_gpio_init();

    precompute_freqs();

    int start_idx = (5000 - FREQ_MIN)/FREQ_STEP;
    if(start_idx<0) start_idx=0;
    if(start_idx>=FREQ_CNT) start_idx=0;
    set_freq_idx((uint16_t)start_idx);
    GPIOB->BRR=(1<<BLINK_PIN);

    // Пробная надпись
//    ssd1306_Fill(Black);
//    ssd1306_SetCursor(0,0);
//    ssd1306_WriteString("USB OK", Font_7x10, White);
//    ssd1306_UpdateScreen();
}

void App_Loop(void)
{
    static int prev_rssi = -999;
    static uint16_t idx = 0;
    static uint8_t last_check_fpv = 0;

    // лампочка
    static uint32_t t_led = 0;
    if ((int32_t)(HAL_GetTick() - t_led) >= 50) {
        GPIOB->ODR ^= (1U<<BLINK_PIN);
        t_led += 50;
    }

    // тик в CDC (диагностика)
    static uint32_t t_tick = 0;
    if ((int32_t)(HAL_GetTick() - t_tick) >= 1000) {
        CDC_Puts("TICK\r\n");
        t_tick += 1000;
    }

    // эхо + команды профиля
    int ch = CDC_Read_Byte();
    if (ch >= 0) {
        CDC_Send_Byte((uint8_t)ch);
        if (ch=='1' || ch=='2') apply_sync_profile_from_cmd((uint8_t)ch);
    }

    // скан частот
    int check_fpv = 0;
    idx++; if(idx>=FREQ_CNT) idx=0;
    set_freq_idx(idx);
    blink_once();

    int rssi = RSSI_dbmcalc(adc_read());
    if(disp_divider++>=DISP_EVERY_N_STEPS || ABS(rssi-prev_rssi)>2)
    {
        SFrq_draw(freq, /*freq+10*/ rssi, check_fpv, last_check_fpv);
        prev_rssi = rssi;
        disp_divider = 0;
    }

    // BURST
    for(int i=0;i<10;i++)
    {
        uint32_t dur = pulse_width_fast();
        if((dur >= sync_low && dur <= sync_high) || (dur >22 && dur<30)) check_fpv++;
        if (check_fpv >= sync_target) break;
    }
    last_check_fpv = (uint8_t)check_fpv;

    // удержание
    if (check_fpv > 4){
        uint32_t t0 = HAL_GetTick();
        SFrq_draw(freq, rssi, check_fpv, last_check_fpv);
        prev_rssi   = rssi;
        disp_divider = 0;

        uint32_t next_draw = HAL_GetTick();
        while ((int32_t)(HAL_GetTick() - t0) < 1500)
        {
            int ch2 = CDC_Read_Byte();
            if (ch2 == '1' || ch2 == '2') {
                apply_sync_profile_from_cmd((uint8_t)ch2);
                CDC_Send_Byte((uint8_t)ch2);
            }

            if ((int32_t)(HAL_GetTick() - next_draw) >= 100) {
                int rssi_hold = RSSI_dbmcalc(adc_read());
                SFrq_draw(freq, rssi_hold, check_fpv, last_check_fpv);
                prev_rssi  = rssi_hold;
                next_draw += 100;
            }
        }

//        idx++; if (idx >= FREQ_CNT) idx = 0;
//        set_freq_idx(idx);
//        blink_once();
    }
}
