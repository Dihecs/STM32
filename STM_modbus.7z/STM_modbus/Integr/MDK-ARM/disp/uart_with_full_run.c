#include "stm32f10x.h"
#include "ssd1306.h"
#include "ssd1306_fonts.h"
#include <stdio.h>
#include <stdint.h>

/* === ВКЛЮЧАЕМ USB CDC вместо UART === */
#define USE_USB_CDC   1

/* --- прототипы из USB-проекта (файлы USB_DEVICE/*) --- */
#ifdef USE_USB_CDC
extern void MX_USB_DEVICE_Init(void);       // из USB_DEVICE/App/usb_device.c
extern int  CDC_Read_Byte(void);            // из usbd_cdc_if.c (наш «мост»)
extern void CDC_Send_Byte(uint8_t b);       //  —//—
extern void CDC_Puts(const char *s);        //  —//—
#endif

/* -------------------- Константы -------------------- */
#define SYSCLK_FREQ     72000000UL
//#define BUTTON_PIN      10
#define RSSI_CHAN       0
#define BURST_PIN       4
#define LED_PIN         12          // PA12 — раньше как «LED», НО ЭТО USB D+ !
#define BLINK_PIN       2

#define SPILE_PIN       12
#define SPICLK_PIN      13
#define SPIDATA_PIN     15

#define FREQ_MIN        4850
#define FREQ_MAX        6200
#define FREQ_STEP       5
#define FREQ_CNT        (((FREQ_MAX - FREQ_MIN) / FREQ_STEP) + 1)

#define RSSI_X          10
#define RSSI_Y          45
#define RSSI_W          98
#define RSSI_H          10
#define RSSI_MINVAL     91

#define ABS(x)          ((x) < 0 ? -(x) : (x))

/* -------------------- Глобальные -------------------- */
static volatile uint32_t msTicks;
static int last_freq = 5000;
static int freq      = 5000;

static uint16_t freq_list[FREQ_CNT];
static uint8_t  disp_divider = 0;
#define DISP_EVERY_N_STEPS 1
static volatile uint32_t hold_until_ms = 0;

/* --- профиль BURST --- */
static volatile uint8_t  sync_target = 5;
static volatile uint16_t sync_low    = 50;
static volatile uint16_t sync_high   = 62;

void clock_config(void);
void SysTick_Handler(void);
void initSysTick(void);
void tim2_init(void);
static inline void delay_us(uint32_t us);
void delay_ms(uint32_t ms);
void gpio_init(void);
void adc_init(void);
uint16_t adc_read(void);
void i2c1_init(void);
void spi_gpio_init(void);
uint32_t pulse_width_fast(void);
int32_t RSSI_dbmcalc(int raw_adc);
int calc_freq_cmd(int f);
void precompute_freqs(void);
static inline void sendSPICommand_rx5808(uint8_t addr, uint8_t rw, uint32_t data);
static inline void set_freq_idx(uint16_t idx);
static inline void blink_once(void);

void SFrq_draw(int f, int rssi, int check_fpv, int pulses);
int last_check_fpv = 0;

/* -------------------- USART1 helpers (оставляем, но не используем) -------------------- */
static inline void usart1_init_115200(void);
static inline int  usart1_read_byte(void);
static inline void usart1_send_byte(uint8_t b);
void Error_Handler(void)
{
  __disable_irq();
  while (1) { }
}
//const uint8_t APBPrescTable[8] = {0,0,0,0,1,2,3,4};
/* -------------------- clock_config -------------------- */
void clock_config(void)
{
    RCC->CR |= RCC_CR_HSION;
    RCC->CFGR = 0;
    RCC->CR &= ~((1 << 16) | (1 << 24));
    RCC->CIR = 0;

    RCC->CR |= RCC_CR_HSEON;
    while (!(RCC->CR & RCC_CR_HSERDY));

    FLASH->ACR |= FLASH_ACR_PRFTBE;
    FLASH->ACR &= ~FLASH_ACR_LATENCY;
    FLASH->ACR |= FLASH_ACR_LATENCY_2;

    RCC->CFGR |= RCC_CFGR_HPRE_DIV1;
    RCC->CFGR |= RCC_CFGR_PPRE1_DIV2;
    RCC->CFGR |= RCC_CFGR_PPRE2_DIV1;
    RCC->CFGR |= RCC_CFGR_ADCPRE_DIV6;

    RCC->CFGR |= RCC_CFGR_PLLSRC;
    RCC->CFGR |= RCC_CFGR_PLLMULL9;

    RCC->CR |= RCC_CR_PLLON;
    while (!(RCC->CR & RCC_CR_PLLRDY));

    RCC->CFGR &= ~RCC_CFGR_SW;
    RCC->CFGR |= RCC_CFGR_SW_PLL;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL){}

    SystemCoreClock = SYSCLK_FREQ;
}

/* -------------------- SysTick -------------------- */
//void SysTick_Handler(void) { msTicks++; }

void initSysTick(void)
{
    SysTick_Config(SystemCoreClock / 1000);
}

void delay_ms(uint32_t ms)
{
    uint32_t tgt = msTicks + ms;
    while (msTicks < tgt);
}

/* -------------------- TIM2 + delay_us -------------------- */
void tim2_init(void)
{
    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;
    TIM2->PSC = (SystemCoreClock / 1000000) - 1;
    TIM2->ARR = 0xFFFFFFFF;
    TIM2->CNT = 0;
    TIM2->CR1 |= TIM_CR1_CEN;
}

static inline void delay_us(uint32_t us)
{
    uint32_t start = TIM2->CNT;
    while ((TIM2->CNT - start) < us);
}

/* -------------------- GPIO -------------------- */
void gpio_init(void)
{
    RCC->APB2ENR |= RCC_APB2ENR_IOPAEN | RCC_APB2ENR_IOPBEN;

    /* BURST вход */
    GPIOA->CRL &= ~(0xF << (BURST_PIN*4));
    GPIOA->CRL |=  (0x8 << (BURST_PIN*4));
    GPIOA->ODR &= ~(1 << BURST_PIN);

#if !USE_USB_CDC
    /* РАНЬШЕ: PA12 как LED — но это USB D+, поэтому при USB-CDC НЕ ТРОГАЕМ PA12 */
    GPIOA->CRH &= ~(0xF << ((LED_PIN-8)*4));
    GPIOA->CRH |=  (0x2 << ((LED_PIN-8)*4));
#endif

    /* PB2 — индикатор */
    GPIOB->CRL &= ~(0xF << (BLINK_PIN*4));
    GPIOB->CRL |=  (0x2 << (BLINK_PIN*4));
    GPIOB->BRR  =  (1 << BLINK_PIN);
}

/* -------------------- ADC -------------------- */
void adc_init(void)
{
    RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;
    ADC1->SMPR2 = 0;
    ADC1->SQR3 = RSSI_CHAN;

    ADC1->CR2 = ADC_CR2_ADON;
    delay_us(10);
    ADC1->CR2 |= ADC_CR2_RSTCAL;
    while (ADC1->CR2 & ADC_CR2_RSTCAL) {}
    ADC1->CR2 |= ADC_CR2_CAL;
    while (ADC1->CR2 & ADC_CR2_CAL) {}
}

uint16_t adc_read(void)
{
    ADC1->CR2 |= ADC_CR2_ADON;
    while (!(ADC1->SR & ADC_SR_EOC)) {}
    return (uint16_t)(ADC1->DR & 0xFFFF);
}

/* -------------------- I2C OLED -------------------- */
void i2c1_init(void)
{
    RCC->APB1ENR |= RCC_APB1ENR_I2C1EN;
    RCC->APB2ENR |= RCC_APB2ENR_IOPBEN;

    GPIOB->CRL &= ~((0xF<<24)|(0xF<<28));
    GPIOB->CRL |=  ((0xB<<24)|(0xB<<28));

    I2C1->CR1 = I2C_CR1_SWRST;
    I2C1->CR1 = 0;
    uint32_t pclk1 = SystemCoreClock/2;
    I2C1->CR2 = (pclk1/1000000);
    uint16_t ccr = pclk1/(3*400000);
    I2C1->CCR = (ccr&0x0FFF)|I2C_CCR_FS;
    I2C1->TRISE = (pclk1/1000000)*300/1000 +1;
    I2C1->CR1 |= I2C_CR1_PE;
}

/* -------------------- SPI BitBang для RX5808 -------------------- */
void spi_gpio_init(void)
{
    RCC->APB2ENR |= RCC_APB2ENR_IOPBEN;
    GPIOB->CRH &= ~((0xF<<16)|(0xF<<20)|(0xF<<28));
    GPIOB->CRH |=  ((0x3<<16)|(0x3<<20)|(0x3<<28)); // 50 МГц
    GPIOB->BSRR = (1<<SPILE_PIN);
}

static inline void sendSPICommand_rx5808(uint8_t addr, uint8_t rw, uint32_t data)
{
    uint32_t cmd = (addr&0x0F) | ((rw&1)<<4) | (data<<5);
    GPIOB->BRR  = (1<<SPILE_PIN);
    delay_us(5);
    for(uint8_t i=0;i<25;i++) {
        if(cmd & 1) GPIOB->BSRR=(1<<SPIDATA_PIN);
        else        GPIOB->BRR =(1<<SPIDATA_PIN);
        GPIOB->BSRR=(1<<SPICLK_PIN);
        delay_us(5);
        GPIOB->BRR =(1<<SPICLK_PIN);
        delay_us(5);
        cmd >>= 1;
    }
    delay_us(5);
    GPIOB->BSRR=(1<<SPILE_PIN);
    delay_us(5);
}

/* -------------------- Измерение BURST -------------------- */
uint32_t pulse_width_fast(void)
{
    uint32_t t0 = TIM2->CNT;
    while((GPIOA->IDR&(1<<BURST_PIN)) && ((TIM2->CNT-t0)<300));
    t0 = TIM2->CNT;
    while(!(GPIOA->IDR&(1<<BURST_PIN)) && ((TIM2->CNT-t0)<300));
    if(!(GPIOA->IDR&(1<<BURST_PIN))) return 0;
    uint32_t t1 = TIM2->CNT;
    while((GPIOA->IDR&(1<<BURST_PIN)) && ((TIM2->CNT-t1)<300));
    return (TIM2->CNT - t1);
}

int32_t RSSI_dbmcalc(int raw_adc)
{
    return -80 + (raw_adc - 750) / 11;
}

/* -------------------- Преобразование и предвычисление -------------------- */
int calc_freq_cmd(int f)
{
    int N = ((f-479)/2)/32;
    int A = ((f-479)/2)%32;
    return (N<<7)|(A&0x1FFF);
}

void precompute_freqs(void)
{
    for(int i=0;i<FREQ_CNT;i++) {
        freq_list[i] = FREQ_MIN + i*FREQ_STEP;
    }
}

static inline void set_freq_idx(uint16_t idx)
{
    freq = freq_list[idx];
    sendSPICommand_rx5808(0x01,1,calc_freq_cmd(freq));
    delay_us(200);
}

static inline void blink_once(void)
{
    GPIOB->BSRR = (1<<BLINK_PIN);
    __NOP(); __NOP();
    GPIOB->BRR  = (1<<BLINK_PIN);
}

/* -------------------- USART1 (оставляем как было) -------------------- */
static inline void usart1_init_115200(void)
{
    RCC->APB2ENR |= RCC_APB2ENR_AFIOEN | RCC_APB2ENR_IOPAEN | RCC_APB2ENR_USART1EN;
    AFIO->MAPR &= ~AFIO_MAPR_USART1_REMAP;

    GPIOA->CRH &= ~((0xF << 4) | (0xF << 8));
    GPIOA->CRH |=  (0xB << 4) | (0x4 << 8);

    USART1->CR1 = 0; USART1->CR2 = 0; USART1->CR3 = 0;
    USART1->BRR = 625;
    USART1->CR1 = USART_CR1_TE | USART_CR1_RE | USART_CR1_UE;
}

static inline int usart1_read_byte(void)
{
    return (USART1->SR & USART_SR_RXNE) ? (USART1->DR & 0xFF) : -1;
}

static inline void usart1_send_byte(uint8_t b)
{
    while (!(USART1->SR & USART_SR_TXE)) {}
    USART1->DR = b;
}

static inline void apply_sync_profile_from_cmd(uint8_t cmd)
{
    if (cmd == '1') { sync_target = 5; sync_low = 50; sync_high = 62; }
    else if (cmd == '2') { sync_target = 4; sync_low = 45; sync_high = 62; }
}

/* -------------------- Отрисовка экрана -------------------- */
void SFrq_draw(int f,int rssi, int check_fpv, int pulses)
{
    char buf[32];
    ssd1306_Fill(Black);
    sprintf(buf,"%d MHz",f);
    ssd1306_SetCursor(0,5);
    ssd1306_WriteString(buf,Font_7x10,White);
    sprintf(buf,"RSSI = %d dBm",rssi);
    ssd1306_SetCursor(0,20);
    ssd1306_WriteString(buf,Font_7x10,White);
    sprintf(buf,"Num_fpv = %d ",check_fpv);
    ssd1306_SetCursor(0,35);
    ssd1306_WriteString(buf,Font_7x10,White);
    ssd1306_SetCursor(0,50);
    sprintf(buf, "SYNC: %u/10", pulses);
    ssd1306_WriteString(buf, Font_7x10, White);
    ssd1306_UpdateScreen();
}

/* -------------------- main -------------------- */
int main(void)
{
    SystemInit();
    clock_config();
    initSysTick();
    tim2_init();
    gpio_init();
    adc_init();
    i2c1_init();
    ssd1306_Init();
    spi_gpio_init();

#if USE_USB_CDC
    /* Приложение под Maple boot20 -> вектора с 0x08005000 */
    SCB->VTOR = 0x08005000; __DSB(); __ISB();

    /* Небольшая пауза и «холодный» ресет USB-периферии */
    delay_ms(50);
    RCC->APB1RSTR |= RCC_APB1RSTR_USBRST; delay_us(2);
    RCC->APB1RSTR &= ~RCC_APB1RSTR_USBRST; delay_us(2);

    /* Старт USB CDC */
    MX_USB_DEVICE_Init();
    /* Можно вывести приветствие в терминал */
    // CDC_Puts("USB-CDC ready\r\n");
#else
    usart1_init_115200();     // (если когда-то вернёшься к пинам)
#endif

    precompute_freqs();

    int prev_rssi = -999;
    int start_idx = (5000 - FREQ_MIN)/FREQ_STEP;
    if(start_idx<0) start_idx=0;
    if(start_idx>=FREQ_CNT) start_idx=0;
    uint16_t idx = start_idx;
    set_freq_idx(idx);
    GPIOB->BRR=(1<<BLINK_PIN);

    while(1)
    {
        /* --- читаем команды --- */
#if USE_USB_CDC
        int ch = CDC_Read_Byte();
#else
        int ch = usart1_read_byte();
#endif
        if (ch == '1' || ch == '2') {
            apply_sync_profile_from_cmd((uint8_t)ch);
#if USE_USB_CDC
            CDC_Send_Byte((uint8_t)ch);
#else
            usart1_send_byte((uint8_t)ch);
#endif
        }

        int check_fpv = 0;

        idx++;
        if(idx>=FREQ_CNT) idx=0;
        set_freq_idx(idx);
        blink_once();

        int rssi = RSSI_dbmcalc(adc_read());
        if(disp_divider++>=DISP_EVERY_N_STEPS || ABS(rssi-prev_rssi)>2)
        {
            SFrq_draw(freq+10, rssi, check_fpv, last_check_fpv);
            prev_rssi = rssi;
            disp_divider = 0;
        }

        /* --- BURST по активному профилю --- */
        for(int i=0;i<10;i++)
        {
            uint32_t dur = pulse_width_fast();
            if(dur >= sync_low && dur <= sync_high || dur >22 && dur<30) check_fpv++;
            if (check_fpv >= sync_target) break;
        }
        last_check_fpv = (uint8_t)check_fpv;

        /* --- удержание --- */
        if (check_fpv > 4){
            uint32_t t0 = msTicks;
            SFrq_draw(freq, rssi, check_fpv, last_check_fpv);
            prev_rssi   = rssi;
            disp_divider = 0;

            uint32_t next_draw = msTicks;
            while ((int32_t)(msTicks - t0) < 1500)
            {
#if USE_USB_CDC
                int ch2 = CDC_Read_Byte();
#else
                int ch2 = usart1_read_byte();
#endif
                if (ch2 == '1' || ch2 == '2') {
                    apply_sync_profile_from_cmd((uint8_t)ch2);
#if USE_USB_CDC
                    CDC_Send_Byte((uint8_t)ch2);
#else
                    usart1_send_byte((uint8_t)ch2);
#endif
                }

                if ((int32_t)(msTicks - next_draw) >= 100) {
                    int rssi_hold = RSSI_dbmcalc(adc_read());
                    SFrq_draw(freq, rssi_hold, check_fpv, last_check_fpv);
                    prev_rssi  = rssi_hold;
                    next_draw += 100;
                }
            }

            idx++;
            if (idx >= FREQ_CNT) idx = 0;
            set_freq_idx(idx);
            blink_once();
            continue;
        }
    }
}
