//#include "stm32f10x.h" 
//#include "ssd1306.h"
//#include <stdlib.h>
//#include <string.h>

//// === ????????? ?????????? ===
//uint8_t SSD1306_Buffer[SSD1306_WIDTH * SSD1306_HEIGHT / 8];
//SSD1306_t SSD1306;
//#define SSD1306_I2C_ADDR   (0x3C << 1)
//// === ???????? ????? ?? I2C1 ===
//void i2c1_send_byte(uint8_t ctrl, uint8_t data) {
//    while (I2C1->SR2 & I2C_SR2_BUSY);           // ????? ???????????? ????

//    I2C1->CR1 |= I2C_CR1_START;                 // ?????
//    while (!(I2C1->SR1 & I2C_SR1_SB));          // ????? SB

//    (void)I2C1->SR1;                            // ???????? SB
//    I2C1->DR = SSD1306_I2C_ADDR;                // ????? ???????
//    while (!(I2C1->SR1 & I2C_SR1_ADDR));        // ????? ?????????????
//    (void)I2C1->SR1;
//    (void)I2C1->SR2;

//    while (!(I2C1->SR1 & I2C_SR1_TXE));
//    I2C1->DR = ctrl;                            // ??????????? ???? (0x00 ??? 0x40)
//    while (!(I2C1->SR1 & I2C_SR1_TXE));
//    I2C1->DR = data;                            // ??????
//    while (!(I2C1->SR1 & I2C_SR1_BTF));         // ????? ??????????

//    I2C1->CR1 |= I2C_CR1_STOP;                  // ????
//}
//// === ???????? ??????? ===
//void ssd1306_WriteCommand(uint8_t byte) {
//    i2c1_send_byte(0x00, byte);  // 0x00 - ???????
//}

//// === ???????? ?????? ===
//void ssd1306_WriteData(uint8_t* buffer, size_t buff_size) {
//    while (I2C1->SR2 & I2C_SR2_BUSY);

//    I2C1->CR1 |= I2C_CR1_START;
//    while (!(I2C1->SR1 & I2C_SR1_SB));

//    (void)I2C1->SR1;
//    I2C1->DR = SSD1306_I2C_ADDR;
//    while (!(I2C1->SR1 & I2C_SR1_ADDR));
//    (void)I2C1->SR1;
//    (void)I2C1->SR2;

//    while (!(I2C1->SR1 & I2C_SR1_TXE));
//    I2C1->DR = 0x40; // ??????????? ????: ??????

//    for (size_t i = 0; i < buff_size; i++) {
//        while (!(I2C1->SR1 & I2C_SR1_TXE));
//        I2C1->DR = buffer[i];
//    }

//    while (!(I2C1->SR1 & I2C_SR1_BTF));
//    I2C1->CR1 |= I2C_CR1_STOP;
//}


//// === ????????????? ??????? ===
//void ssd1306_Init(void) {
//    for (volatile int i = 0; i < 100000; i++);  // ????????

//    ssd1306_WriteCommand(0xAE); // ????????? ???????
//    ssd1306_WriteCommand(0x20); // ????? ?????????
//    ssd1306_WriteCommand(0x00); // ?????????????? ?????
//    ssd1306_WriteCommand(0xB0);
//    ssd1306_WriteCommand(0xC8);
//    ssd1306_WriteCommand(0x00);
//    ssd1306_WriteCommand(0x10);
//    ssd1306_WriteCommand(0x40);
//    ssd1306_WriteCommand(0x81);
//    ssd1306_WriteCommand(0xFF);
//    ssd1306_WriteCommand(0xA1);
//    ssd1306_WriteCommand(0xA6);
//    ssd1306_WriteCommand(0xA8);
//    ssd1306_WriteCommand(0x3F);
//    ssd1306_WriteCommand(0xA4);
//    ssd1306_WriteCommand(0xD3);
//    ssd1306_WriteCommand(0x00);
//    ssd1306_WriteCommand(0xD5);
//    ssd1306_WriteCommand(0xF0);
//    ssd1306_WriteCommand(0xD9);
//    ssd1306_WriteCommand(0x22);
//    ssd1306_WriteCommand(0xDA);
//    ssd1306_WriteCommand(0x12);
//    ssd1306_WriteCommand(0xDB);
//    ssd1306_WriteCommand(0x20);
//    ssd1306_WriteCommand(0x8D);
//    ssd1306_WriteCommand(0x14);
//    ssd1306_WriteCommand(0xAF); // ???????? ???????

//    ssd1306_Fill(Black);
//    ssd1306_UpdateScreen();

//    SSD1306.CurrentX = 0;
//    SSD1306.CurrentY = 0;
//    SSD1306.Initialized = 1;
//}

//// === ???????? ????? ===
//void ssd1306_UpdateScreen(void) {
//    for (uint8_t page = 0; page < 8; page++) {
//        ssd1306_WriteCommand(0xB0 + page);
//        ssd1306_WriteCommand(0x00);
//        ssd1306_WriteCommand(0x10);
//        ssd1306_WriteData(&SSD1306_Buffer[SSD1306_WIDTH * page], SSD1306_WIDTH);
//    }
//}

//// === ??????? ?????? ===
//void ssd1306_Fill(SSD1306_COLOR color) {
//    memset(SSD1306_Buffer, (color == Black) ? 0x00 : 0xFF, sizeof(SSD1306_Buffer));
//}

//// === ????????? ??????? ===
//void ssd1306_SetCursor(uint8_t x, uint8_t y) {
//    SSD1306.CurrentX = x;
//    SSD1306.CurrentY = y;
//}

//// === ?????????? ??????? ===
//void ssd1306_DrawPixel(uint8_t x, uint8_t y, SSD1306_COLOR color) {
//    if (x >= SSD1306_WIDTH || y >= SSD1306_HEIGHT) return;
//    if (color == White)
//        SSD1306_Buffer[x + (y / 8) * SSD1306_WIDTH] |= (1 << (y % 8));
//    else
//        SSD1306_Buffer[x + (y / 8) * SSD1306_WIDTH] &= ~(1 << (y % 8));
//}

//// === ?????????? ????????????? ===
//void ssd1306_DrawRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, SSD1306_COLOR color) {
//	 uint8_t i;
//    for (uint8_t i = 0; i < w; i++) {
//        ssd1306_DrawPixel(x + i, y, color);
//        ssd1306_DrawPixel(x + i, y + h - 1, color);
//    }
//    for (uint8_t i = 0; i < h; i++) {
//        ssd1306_DrawPixel(x, y + i, color);
//        ssd1306_DrawPixel(x + w - 1, y + i, color);
//    }
//}

//// === ?????? ????????????? ===
//void ssd1306_FillRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, SSD1306_COLOR color) {
//	 uint8_t i, j;
//    for (uint8_t i = 0; i < h; i++) {
//        for (uint8_t j = 0; j < w; j++) {
//            ssd1306_DrawPixel(x + j, y + i, color);
//        }
//    }
//}

//// === ?????????? ?????? ===
//char ssd1306_WriteChar(char ch, SSD1306_Font_t Font, SSD1306_COLOR color) {
//    uint16_t i, b;
//    if (ch < 32 || ch > 126) return 0;

//    for (i = 0; i < Font.height; i++) {
//        b = Font.data[(ch - 32) * Font.height + i];
//        for (uint8_t j = 0; j < Font.width; j++) {
//            if ((b << j) & 0x8000)
//                ssd1306_DrawPixel(SSD1306.CurrentX + j, SSD1306.CurrentY + i, color);
//            else
//                ssd1306_DrawPixel(SSD1306.CurrentX + j, SSD1306.CurrentY + i, !color);
//        }
//    }
//    SSD1306.CurrentX += Font.width;
//    return ch;
//}

//// === ???????? ?????? ===
//char ssd1306_WriteString(char* str, SSD1306_Font_t Font, SSD1306_COLOR color) {
//    while (*str) {
//        if (ssd1306_WriteChar(*str, Font, color) != *str) return *str;
//        str++;
//    }
//    return *str;
//}






// ssd1306.c � ?????? ? ????-?????? ? I2C1 LL
// ???????? ? ??????? CubeMX (HAL). ?????: I2C1 PB6=SCL, PB7=SDA.

#include "main.h"              // ????? HAL ? ???????
#include "ssd1306.h"
#include <string.h>
#include <stdlib.h>
#ifndef SSD1306_I2C_ADDR
#define SSD1306_I2C_ADDR  0x3C
#endif
// ==================== ????????????/????? ====================
// ? ssd1306_conf.h (??? ???-?? ? ???????) ?????? ????:
//   #define SSD1306_I2C_ADDR  0x3C  // 7-?????? ????? ??????
// ???? ??????????? ? 8-?????? (??? ??????? ???? ?????????????? ???????):
//#if (SSD1306_I2C_ADDR <= 0x7F)
  #define SSD1306_ADDR8  ((SSD1306_I2C_ADDR) << 1)   // 0x3C -> 0x78
//#else
  ///#define SSD1306_ADDR8  (SSD1306_I2C_ADDR)          // ???? ??? 8-??????
//#endif

// ==================== ??????? ?????? ====================
uint8_t   SSD1306_Buffer[SSD1306_WIDTH * SSD1306_HEIGHT / 8];
SSD1306_t SSD1306;

// ==================== ??????????????? ??????? ====================
// ???????? ????-????, ????? ?? ???????? ????????.
// ??????? ?? ??????? ??? ????????? ????-???? (????).
#define I2C_WAIT_UNTIL(cond, tout_ms)                                          \
  do {                                                                         \
    uint32_t __t0 = HAL_GetTick();                                             \
    while (!(cond)) {                                                          \
      if ((int32_t)(HAL_GetTick() - __t0) > (int32_t)(tout_ms)) {              \
        return;                                                                \
      }                                                                        \
    }                                                                          \
  } while (0)

#define I2C_WAIT_WHILE(cond, tout_ms)                                          \
  do {                                                                         \
    uint32_t __t0 = HAL_GetTick();                                             \
    while ((cond)) {                                                           \
      if ((int32_t)(HAL_GetTick() - __t0) > (int32_t)(tout_ms)) {              \
        return;                                                                \
      }                                                                        \
    }                                                                          \
  } while (0)

// ???????? ???????? ????? ?????????? ?? ????????? ?????
static inline void ssd1306_uDelay_soft(uint32_t n)
{
  for (volatile uint32_t i = 0; i < n; ++i) __NOP();
}

// ==================== ?????????????? I2C-???????? ====================
// ????? + ????? + ??????????? ???? (0x00 � ???????, 0x40 � ??????)
static void i2c1_start_ctrl(uint8_t ctrl_byte)
{
  // ????, ????? ???? ???????????
  I2C_WAIT_WHILE(I2C1->SR2 & I2C_SR2_BUSY, 5);

  // START
  I2C1->CR1 |= I2C_CR1_START;
  I2C_WAIT_UNTIL((I2C1->SR1 & I2C_SR1_SB), 5);

  (void)I2C1->SR1;                 // ?????? SR1 ?????????? SB

  // ????? (8-??????)
  I2C1->DR = SSD1306_ADDR8;
  I2C_WAIT_UNTIL((I2C1->SR1 & I2C_SR1_ADDR), 5);
  (void)I2C1->SR1; (void)I2C1->SR2; // ????? ????? ADDR

  // ??????????? ???? (0x00 � ???????, 0x40 � ??????)
  I2C_WAIT_UNTIL((I2C1->SR1 & I2C_SR1_TXE), 5);
  I2C1->DR = ctrl_byte;
  I2C_WAIT_UNTIL((I2C1->SR1 & I2C_SR1_TXE), 5);
}

// STOP
static inline void i2c1_stop(void)
{
  I2C1->CR1 |= I2C_CR1_STOP;
  ssd1306_uDelay_soft(200);
}

// ==================== API: ???????/?????? ====================
void ssd1306_WriteCommand(uint8_t byte)
{
  i2c1_start_ctrl(0x00);                 // ??????????? = ???????
  I2C1->DR = byte;
  I2C_WAIT_UNTIL((I2C1->SR1 & I2C_SR1_BTF), 5);
  i2c1_stop();
}

void ssd1306_WriteData(uint8_t* buffer, size_t len)
{
  if (!len) return;

  i2c1_start_ctrl(0x40);                 // ??????????? = ??????

  // ???? ???????????????, ?? ???????
  for (size_t i = 0; i < len; ++i) {
    I2C_WAIT_UNTIL((I2C1->SR1 & I2C_SR1_TXE), 5);
    I2C1->DR = buffer[i];
  }

  I2C_WAIT_UNTIL((I2C1->SR1 & I2C_SR1_BTF), 5);
  i2c1_stop();
}

// ==================== ????????????? ??????? ====================
void ssd1306_Init(void)
{
  // ????????????: ??????? ACK ? ?????? (???? ???-?? ???????)
  I2C1->CR1 |= (I2C_CR1_ACK | I2C_CR1_PE);

  HAL_Delay(15); // ??????? ????? ??????? >10 ?? ????? ???????

  // ?????????????????? ????????????? SSD1306 (???????, ?????????????? ?????????)
  ssd1306_WriteCommand(0xAE); // Display OFF
  ssd1306_WriteCommand(0x20); // Memory Addressing Mode
  ssd1306_WriteCommand(0x00); // Horizontal Addressing Mode
  ssd1306_WriteCommand(0xB0); // Page Start Address for Page Addressing Mode
  ssd1306_WriteCommand(0xC8); // COM Output Scan Direction remapped
  ssd1306_WriteCommand(0x00); // Low column
  ssd1306_WriteCommand(0x10); // High column
  ssd1306_WriteCommand(0x40); // Start line = 0
  ssd1306_WriteCommand(0x81); // Contrast
  ssd1306_WriteCommand(0x7F);
  ssd1306_WriteCommand(0xA1); // Segment remap
  ssd1306_WriteCommand(0xA6); // Normal display
  ssd1306_WriteCommand(0xA8); // Multiplex ratio
  ssd1306_WriteCommand(0x3F); // 1/64
  ssd1306_WriteCommand(0xA4); // Display follows RAM
  ssd1306_WriteCommand(0xD3); // Display offset
  ssd1306_WriteCommand(0x00);
  ssd1306_WriteCommand(0xD5); // Display clock divide
  ssd1306_WriteCommand(0x80);
  ssd1306_WriteCommand(0xD9); // Pre-charge period
  ssd1306_WriteCommand(0x22);
  ssd1306_WriteCommand(0xDA); // COM pins
  ssd1306_WriteCommand(0x12);
  ssd1306_WriteCommand(0xDB); // VCOMH deselect
  ssd1306_WriteCommand(0x20);
  ssd1306_WriteCommand(0x8D); // Charge pump
  ssd1306_WriteCommand(0x14);
  ssd1306_WriteCommand(0xAF); // Display ON

  ssd1306_Fill(Black);
  ssd1306_UpdateScreen();

  SSD1306.CurrentX   = 0;
  SSD1306.CurrentY   = 0;
  SSD1306.Initialized = 1;
}

// ==================== ?????????? ?????? ====================
void ssd1306_UpdateScreen(void)
{
  for (uint8_t page = 0; page < 8; page++) {
    ssd1306_WriteCommand(0xB0 + page);
    ssd1306_WriteCommand(0x00);
    ssd1306_WriteCommand(0x10);
    ssd1306_WriteData(&SSD1306_Buffer[SSD1306_WIDTH * page], SSD1306_WIDTH);
  }
}

// ==================== ????????? ====================
void ssd1306_Fill(SSD1306_COLOR color)
{
  memset(SSD1306_Buffer, (color == Black) ? 0x00 : 0xFF, sizeof(SSD1306_Buffer));
}

void ssd1306_SetCursor(uint8_t x, uint8_t y)
{
  SSD1306.CurrentX = x;
  SSD1306.CurrentY = y;
}

void ssd1306_DrawPixel(uint8_t x, uint8_t y, SSD1306_COLOR color)
{
  if (x >= SSD1306_WIDTH || y >= SSD1306_HEIGHT) return;

  if (color == White)
    SSD1306_Buffer[x + (y / 8) * SSD1306_WIDTH] |=  (1 << (y % 8));
  else
    SSD1306_Buffer[x + (y / 8) * SSD1306_WIDTH] &= ~(1 << (y % 8));
}

void ssd1306_DrawRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, SSD1306_COLOR color)
{
  if (!w || !h) return;
  for (uint8_t i = 0; i < w; i++) {
    ssd1306_DrawPixel(x + i, y,         color);
    ssd1306_DrawPixel(x + i, y + h - 1, color);
  }
  for (uint8_t i = 0; i < h; i++) {
    ssd1306_DrawPixel(x,         y + i, color);
    ssd1306_DrawPixel(x + w - 1, y + i, color);
  }
}

void ssd1306_FillRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, SSD1306_COLOR color)
{
  if (!w || !h) return;
  for (uint8_t i = 0; i < h; i++)
    for (uint8_t j = 0; j < w; j++)
      ssd1306_DrawPixel(x + j, y + i, color);
}

// ??????/?????? � ??????? ??? ? ????, ?????? ?????? ? ?????????? ??????:
char ssd1306_WriteChar(char ch, SSD1306_Font_t Font, SSD1306_COLOR color)
{
  if (ch < 32 || ch > 126) return 0;

  for (uint16_t i = 0; i < Font.height; i++) {
    uint16_t row = Font.data[(ch - 32) * Font.height + i];
    for (uint8_t j = 0; j < Font.width; j++) {
      if ((row << j) & 0x8000)
        ssd1306_DrawPixel(SSD1306.CurrentX + j, SSD1306.CurrentY + i, color);
      else
        ssd1306_DrawPixel(SSD1306.CurrentX + j, SSD1306.CurrentY + i, (SSD1306_COLOR)!color);
    }
  }
  SSD1306.CurrentX += Font.width;
  return ch;
}

char ssd1306_WriteString(char* str, SSD1306_Font_t Font, SSD1306_COLOR color)
{
  while (*str) {
    if (ssd1306_WriteChar(*str, Font, color) != *str) return *str;
    str++;
  }
  return *str;
}
