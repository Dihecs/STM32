#include "main.h"
#include "stm32f1xx_hal.h"
#include "usbd_cdc_if.h"

#include "ssd1306.h"
#include "ssd1306_fonts.h"

#include <stdio.h>
#include <stdint.h>
#include <stdarg.h>

/* ======================= USB‑CDC helpers ======================= */
extern int  CDC_Read_Byte(void);
extern void CDC_Send_Byte(uint8_t b);
extern void CDC_Puts(const char *s);

static void cdc_printf(const char *fmt, ...)
{
    char buf[256];
    va_list ap; va_start(ap, fmt);
    int n = vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    if (n < 0) return;
    if (n >= (int)sizeof(buf)) { buf[sizeof(buf)-2]='\n'; buf[sizeof(buf)-1]='\0'; }
    CDC_Puts(buf);
}

static void log_pulses_line(const char *prefix, uint32_t pass_no, const uint16_t *dur, int cnt)
{
    char line[256]; int pos = 0;
    if (prefix && prefix[0]) pos += snprintf(line+pos, sizeof(line)-pos, "%s", prefix);
    if (pass_no)             pos += snprintf(line+pos, sizeof(line)-pos, " %lu", (unsigned long)pass_no);
    pos += snprintf(line+pos, sizeof(line)-pos, " - ");
    for (int i = 0; i < cnt; i++) {
        pos += snprintf(line+pos, sizeof(line)-pos, "%d=%u", i+1, (unsigned)dur[i]);
        if (i != cnt-1) pos += snprintf(line+pos, sizeof(line)-pos, ", ");
        if (pos >= (int)sizeof(line)-8) break;
    }
    pos += snprintf(line+pos, sizeof(line)-pos, "\r\n");
    CDC_Puts(line);
}

/* ======================= Пины/настройки ======================= */
#define RSSI_CHAN        0              // ADC1_IN0 (PA0)
#define BURST_PIN        4              // PA4 — вход от LM1881
#define BLINK_PIN        2              // PB2 — краткий импульс при перестройке

// FT200 bit‑bang "SPI"
#define FT_LE_PIN       12              // PB12 LE (Latch Enable)
#define FT_SCK_PIN      13              // PB13 SCK
#define FT_MOSI_PIN     15              // PB15 MOSI

/* Диапазон 3 ГГц (как в твоём коде с визуальным сдвигом) */
static const int freq_smesh = 480;      // только для подписи на экране
#define FREQ_MIN      (3100 - 480)      // внутренняя шкала для FT200
#define FREQ_MAX      (3800 - 480)
#define FREQ_STEP            5

/* BURST профиль (управляется командами '1'/'2' по USB) */
static volatile uint8_t  sync_target = 5;   // нужно >=5 попаданий из 10
static volatile uint16_t sync_low    = 54;  // окно BURST, мкс (около 60 мкс)
static volatile uint16_t sync_high   = 64;

/* Глобальные */
static int      freq       = 3000;     // текущая частота (внутренняя шкала)
static uint8_t  last_check_fpv = 0;    // для экрана

/* ======================= TIM2 + задержки ======================= */
static void tim2_init(void)
{
    __HAL_RCC_TIM2_CLK_ENABLE();
    TIM2->PSC = (HAL_RCC_GetHCLKFreq()/1000000UL) - 1;   // 1 МГц
    TIM2->ARR = 0xFFFFFFFF; TIM2->CNT = 0; TIM2->CR1 |= TIM_CR1_CEN;
}

static inline void delay_us(uint32_t us)
{
    uint32_t start = TIM2->CNT; while ((uint32_t)(TIM2->CNT - start) < us) { __NOP(); }
}

/* ======================= GPIO ======================= */
static void gpio_init(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    // PA4 = вход (floating)
    GPIOA->CRL &= ~(0xF << (BURST_PIN*4));
    GPIOA->CRL |=  (0x4 << (BURST_PIN*4));

    // PB2 = output PP 2 MHz (индикатор/щелчок перестройки)
    GPIOB->CRL &= ~(0xF << (BLINK_PIN*4));
    GPIOB->CRL |=  (0x2 << (BLINK_PIN*4));
    GPIOB->BRR   = (1U << BLINK_PIN);

    // FT200 bit‑bang: PB12/PB13/PB15 = output PP 2 MHz
    GPIOB->CRH &= ~((0xF<<16)|(0xF<<20)|(0xF<<28));
    GPIOB->CRH |=  ((0x3<<16)|(0x3<<20)|(0x3<<28));
    GPIOB->BSRR  = (1U<<FT_LE_PIN); // LE=1 в покое
}

/* ======================= ADC ======================= */
static void adc_init(void)
{
    __HAL_RCC_ADC1_CLK_ENABLE();
    ADC1->CR2 = 0; ADC1->SMPR2 = 0; ADC1->SQR3 = RSSI_CHAN;
    ADC1->CR2 = ADC_CR2_ADON; delay_us(10);
    ADC1->CR2 |= ADC_CR2_RSTCAL; while (ADC1->CR2 & ADC_CR2_RSTCAL) {}
    ADC1->CR2 |= ADC_CR2_CAL;    while (ADC1->CR2 & ADC_CR2_CAL)    {}
}

static uint16_t adc_read(void)
{
    ADC1->CR2 |= ADC_CR2_ADON; while (!(ADC1->SR & ADC_SR_EOC)) {}
    return (uint16_t)(ADC1->DR & 0x0FFF);
}

/* ======================= I2C1 (OLED) ======================= */
static void i2c1_init(void)
{
    __HAL_RCC_I2C1_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    // PB6=SCL, PB7=SDA: AF Open‑Drain, 50 МГц
    GPIOB->CRL &= ~((0xF<<24)|(0xF<<28));
    GPIOB->CRL |=  ((0xB<<24)|(0xB<<28));

    I2C1->CR1 = I2C_CR1_SWRST; I2C1->CR1 = 0;
    // Fast‑mode ~400 кГц при PCLK1=36 МГц
    I2C1->CR2   = 36;
    I2C1->CCR   = I2C_CCR_FS | (0<<I2C_CCR_DUTY_Pos) | 30;  // ≈400 кГц
    I2C1->TRISE = 11;                                       // ~300 нс
    I2C1->CR1  |= I2C_CR1_PE;
}

/* ======================= LM1881: измерение HIGH ======================= */
static uint32_t pulse_width_fast(void)
{
    uint32_t t0 = TIM2->CNT;
    while (!(GPIOA->IDR & (1U<<BURST_PIN)) && (TIM2->CNT - t0) < 400) { }
    if (!(GPIOA->IDR & (1U<<BURST_PIN))) return 0;
    uint32_t t1 = TIM2->CNT;
    while ( (GPIOA->IDR & (1U<<BURST_PIN)) && (TIM2->CNT - t1) < 400) { }
    return (TIM2->CNT - t1);
}

/* ======================= RSSI калибровка (простая) ======================= */
static int32_t RSSI_dbmcalc(int freq_internal, int RSSI_analog)
{
    // Приводим 12-битный АЦП STM32 (0..4095) к шкале Arduino (0..1023),
    // т.к. калибровка ниже подобрана под старые коэффициенты из Arduino-версии.
    double RSSI_analog_double = (double)RSSI_analog * (1023.0 / 4095.0);

    int freq = freq_internal + freq_smesh; // визуальный сдвиг как в твоём коде

    double koef = 0.760976;
    int big_freq = 3150;
    int diff = 150;

    if (freq >= 3135) {
        if (freq <= 3355) {
            koef = 0.760976;
            big_freq = 3150;
            diff = 150;
        } else if (freq <= 3485) {
            koef = -1.656;
            big_freq = 3360;
            diff = 0;
        } else if (freq <= 3670) {
            koef = 0.333333;
            big_freq = 3490;
            diff = 150;
        } else if (freq <= 3690) {
            koef = -8.666667;
            big_freq = 3675;
            diff = 150;
        }

        if (freq <= 3690) {
            RSSI_analog_double = RSSI_analog_double - (freq - big_freq) * koef - (400 - diff);
        }
    }

    if (freq == 3715) {
        RSSI_analog_double -= 100.0;
    }

    // Линейная аппроксимация из Arduino-кода
    double k_coef = 0.468;
    int    b_coef = 200; // 139 в старом варианте; оставляем 200 как у тебя
    double RSSI_buf = k_coef * RSSI_analog_double - b_coef;

    // Сдвиг +50 как у тебя
    return (int)(RSSI_buf + 50.0);
}


/* ======================= FT200: регистры/частота ======================= */
// Константы PLL (синхронизированы с твоим Arduino-кодом)
#define REG_DELAY_EDGES 10
#define rf_div   1
#define ref_fr  50
#define r_prsc   1
#define modulus 131070UL

#define lk_sw    1
#define vco_bit  2
#define en_cp    1
#define spi_cp   24
#define fdiv_sw  1
#define conrt3b  1
#define muxout   1
#define vco_cur  1
#define vco_sel  1      // верхний диапазон VCO (2.4–3.24 ГГц)
#define afc_or_spi 1    // AFC включен
#define spi_vco6b 53
#define vco_cnt  800
#define md_is    0
#define ld_sw    2
#define pfd_delay_d  0
#define pfd_delay_en 1
#define lfsr_sel 2
#define bit_sel  2

static inline void FT200_send_reg32(uint32_t w)
{
    GPIOB->BRR  = (1U<<FT_LE_PIN); // LE=0
    delay_us(5);
    for (int i = 31; i >= 0; --i) {
        GPIOB->BRR  = (1U<<FT_SCK_PIN);
        if (w & (1UL<<i)) GPIOB->BSRR = (1U<<FT_MOSI_PIN); else GPIOB->BRR = (1U<<FT_MOSI_PIN);
        GPIOB->BSRR = (1U<<FT_SCK_PIN); delay_us(5);
    }
    GPIOB->BRR  = (1U<<FT_SCK_PIN);
    GPIOB->BSRR = (1U<<FT_LE_PIN); // защёлкнуть
    delay_us(5);
    for (int i=0;i<REG_DELAY_EDGES;i++){ GPIOB->BRR=(1U<<FT_SCK_PIN); __NOP(); GPIOB->BSRR=(1U<<FT_SCK_PIN); __NOP(); }
}

static inline void FT200_set_freq_MHz(int f_mhz)
{
    double f_pfd = (double)ref_fr / (double)r_prsc;
    double coeff = (double)rf_div * (double)f_mhz / f_pfd; // INT + FRAC/MOD

    uint16_t INT = (uint16_t)coeff;
    double   frac= coeff - (double)INT;
    uint32_t FRAC= (uint32_t)(frac * (double)modulus + 0.5);

    uint32_t REG1 = (0u<<31)|(0u<<30)|(1u<<29)|(0u<<28) | ((uint32_t)fdiv_sw<<27) | ((uint32_t)conrt3b<<24) | ((FRAC & 0xFFFFFFu)<<0);
    uint32_t REG2 = (0u<<31)|(1u<<30)|(0u<<29)|(0u<<28) | ((uint32_t)muxout<<25) | ((uint32_t)(modulus & 0x1FFFFFFu)<<0);
    uint32_t REG3 = (0u<<31)|(1u<<30)|(1u<<29)|(0u<<28) | ((uint32_t)vco_cur<<25) | ((uint32_t)vco_sel<<24) | ((uint32_t)afc_or_spi<<22) |
                    ((uint32_t)spi_vco6b<<16) | (1u<<15)|(1u<<14)|(0u<<13)|(0u<<12)|(1u<<11)|(0u<<10)|(0u<<9)|(0u<<8) |
                    ((uint32_t)vco_cnt<<2) | ((uint32_t)md_is);
    uint32_t REG4 = (1u<<31)|(0u<<30)|(0u<<29)|(0u<<28) | ((uint32_t)ld_sw<<26) | ((uint32_t)0<<21) | ((uint32_t)(r_prsc & 0x3FFF)<<7) | ((uint32_t)(rf_div & 0x7F));
    uint32_t REG5 = (1u<<31)|(0u<<30)|(1u<<29)|(0u<<28) |
                    (0u<<27)|(0u<<26)|(0u<<25)|(0u<<24)|(0u<<23)|(0u<<22)|(0u<<21)|(0u<<20)|(0u<<19)|(0u<<18)|(0u<<17)|(0u<<16)|
                    (0u<<15)|(0u<<14)|(0u<<13)|(0u<<12)|(0u<<11)|(0u<<10)|(0u<<9)|(0u<<8)|(0u<<7)|(0u<<6)|
                    ((uint32_t)pfd_delay_d<<5) | ((uint32_t)pfd_delay_en<<4) | ((uint32_t)lfsr_sel<<2) | ((uint32_t)bit_sel<<0);
    uint32_t REG0 = (0u<<31)|(0u<<30)|(0u<<29)|(0u<<28) | ((uint32_t)lk_sw<<27) | ((uint32_t)vco_bit<<25) | ((uint32_t)en_cp<<24) |
                    ((uint32_t)(spi_cp & 0xFF)<<16) | ((uint32_t)(INT & 0xFFFF));

    FT200_send_reg32(REG1); FT200_send_reg32(REG2); FT200_send_reg32(REG3);
    FT200_send_reg32(REG4); FT200_send_reg32(REG5); FT200_send_reg32(REG0);
    delay_us(300); // дать PLL захватиться
}

/* ======================= Вспомогательные ======================= */
static inline void blink_once(void)
{   // краткий импульс на PB2 (для осциллографа)
    GPIOB->BSRR = (1U<<BLINK_PIN); __NOP(); __NOP(); GPIOB->BRR = (1U<<BLINK_PIN);
}

static inline void apply_sync_profile_from_cmd(uint8_t cmd)
{
    if (cmd == '1') { sync_target = 5; sync_low = 54; sync_high = 64; }
    else if (cmd == '2') { sync_target = 4; sync_low = 45; sync_high = 62; }
}

static void SFrq_draw(int f_internal, int rssi_dbm, int hits, int pulses)
{
    char buf[32]; int f_disp = f_internal + freq_smesh;
    ssd1306_Fill(Black);
    ssd1306_SetCursor(0,5);  snprintf(buf, sizeof(buf), "%d MHz", f_disp); ssd1306_WriteString(buf, Font_7x10, White);
    ssd1306_SetCursor(0,20); snprintf(buf, sizeof(buf), "RSSI = %d dBm", rssi_dbm); ssd1306_WriteString(buf, Font_7x10, White);
    ssd1306_SetCursor(0,35); snprintf(buf, sizeof(buf), "Num_fpv = %d/10", hits); ssd1306_WriteString(buf, Font_7x10, White);
    (void)pulses; // оставлено под будущее
    ssd1306_UpdateScreen();
}

static inline void set_freq_MHz(int fMHz)
{   // именно FT200
    FT200_set_freq_MHz(fMHz);
    HAL_Delay(3); (void)adc_read();          // прожечь первое чтение
}

static inline void next_freq_step(void)
{
    freq += FREQ_STEP; if (freq > FREQ_MAX) freq = FREQ_MIN;
}

/* ======================= App_Init / App_Loop ======================= */
void App_Init(void)
{
    HAL_Delay(50);
    tim2_init(); gpio_init(); adc_init(); i2c1_init();
    ssd1306_Init();

    // стартовая частота
    if (freq < FREQ_MIN || freq > FREQ_MAX) freq = FREQ_MIN;
    set_freq_MHz(freq);

    ssd1306_Fill(Black);
    ssd1306_SetCursor(0,0); ssd1306_WriteString("USB OK", Font_7x10, White);
    ssd1306_UpdateScreen();
}

void App_Loop(void)
{
    static int  prev_rssi = -999;
    static uint32_t pass_no = 0;   // счётчик проходов по частоте

    // приём команд профиля
    int ch = CDC_Read_Byte(); if (ch == '1' || ch == '2') { apply_sync_profile_from_cmd((uint8_t)ch); CDC_Send_Byte((uint8_t)ch); }

    // Перестройка и короткий импульс‑маяк
    set_freq_MHz(freq); blink_once();

    // RSSI и (редкая) перерисовка
    int rssi = RSSI_dbmcalc(freq, adc_read());
    if (prev_rssi == -999 || (rssi - prev_rssi > 2) || (prev_rssi - rssi > 2)) { SFrq_draw(freq, rssi, 0, last_check_fpv); prev_rssi = rssi; }

    // BURST: 10 измерений
    int check_fpv = 0; uint16_t dur_list[10]; int dur_cnt = 0;
    for (int i = 0; i < 10; i++) {
        uint32_t d = pulse_width_fast();
        if (d > 0 && d < 300 && dur_cnt < 10) dur_list[dur_cnt++] = (uint16_t)d;
        if (d >= sync_low && d <= sync_high) {
            check_fpv++; if (check_fpv >= sync_target) break;
        }
    }
    last_check_fpv = (uint8_t)check_fpv; pass_no++; log_pulses_line("Prohod", pass_no, dur_list, dur_cnt);

    // Удержание при нахождении сигнала (двойная проверка)
    if (check_fpv >= sync_target) {
        set_freq_MHz(freq); HAL_Delay(3); (void)adc_read();
        int confirm = 0; for (int i = 0; i < 10; i++) { uint32_t d2 = pulse_width_fast(); if (d2 >= sync_low && d2 <= sync_high) { confirm++; if (confirm >= sync_target) break; } }
        if (confirm < sync_target) { next_freq_step(); return; }

        // Лог сразу после остановки — короткая серия длительностей
        uint16_t dur_hold[12]; int cnt_hold = 0; for (int i=0;i<12;i++){ uint32_t d = pulse_width_fast(); if (d>0 && d<300 && cnt_hold<12) dur_hold[cnt_hold++] = (uint16_t)d; }
        log_pulses_line("Stood", 0, dur_hold, cnt_hold);

        // 1.5 секунды HOLD с обновлением экрана и приёмом команд '1'/'2'
        uint32_t t0 = HAL_GetTick(), next_draw = HAL_GetTick();
        while ((int32_t)(HAL_GetTick() - t0) < 1500) {
            int ch2 = CDC_Read_Byte(); if (ch2 == '1' || ch2 == '2') { apply_sync_profile_from_cmd((uint8_t)ch2); CDC_Send_Byte((uint8_t)ch2); }
            if ((int32_t)(HAL_GetTick() - next_draw) >= 100) {
                int rssi_hold = RSSI_dbmcalc(freq, adc_read()); SFrq_draw(freq, rssi_hold, check_fpv, last_check_fpv); prev_rssi = rssi_hold; next_draw += 100;
            }
        }
        next_freq_step();
        return;
    }

    // иначе — обычный шаг по кругу
    next_freq_step();
}
