#include "main.h"
#include "usb_device.h"
#include "gpio.h"
#include <stdio.h>          // ??? snprintf
#include "stm32f1xx_hal.h"

#include "ssd1306.h"
#include "ssd1306_fonts.h"

#include "app.h"


//extern void CDC_Puts(const char *s);  // ?? usbd_cdc_if.c
//extern int  CDC_Read_Byte(void);
//extern void CDC_Send_Byte(uint8_t b);
//// ???????, ??? ? system_stm32f1xx.c:
//// #define VECT_TAB_BASE   FLASH_BASE
//// #define VECT_TAB_OFFSET 0x00005000U   // = 0x08005000
//// ? HSE_VALUE ????????????? ?????? ?????? (?????? 8000000U).
void Error_Handler(void)
{
////  // ??????? ???????????? GPIOB ? ???????? PB2 ???? ????? ?? ????????
////  RCC->APB2ENR |= RCC_APB2ENR_IOPBEN;
////  GPIOB->CRL &= ~(0xF << (2*4));
////  GPIOB->CRL |=  (0x2 << (2*4));   // PB2 = Output PP 2MHz

////  while (1) {
////    GPIOB->ODR ^= (1U<<2);
////    for (volatile uint32_t i=0; i<300000; ++i) __NOP(); // ~??????? ???????
////  }
}
//static void i2c1_init(void)
//{
//    // ????????????
//    RCC->APB2ENR |= RCC_APB2ENR_AFIOEN | RCC_APB2ENR_IOPBEN;
//    RCC->APB1ENR |= RCC_APB1ENR_I2C1EN;

//    // ????? ????????? ????? I2C1 -> PB8/PB9
//    AFIO->MAPR &= ~AFIO_MAPR_I2C1_REMAP;   // ????????? PB6/PB7

//    // PB6=SCL, PB7=SDA: AF Open-Drain, 50 ???
//    GPIOB->CRL &= ~((0xF << 24) | (0xF << 28));
//    GPIOB->CRL |=  ((0xB << 24) | (0xB << 28));

//    // ??????? ????? ? ?????? ?????????????
//    I2C1->CR1 = I2C_CR1_SWRST;
//    I2C1->CR1 = 0;

//    // PCLK1 = 36 ???
//    I2C1->CR2 = 36;
//    // 100 ???: CCR = 180, TRISE = 37
//    I2C1->CCR   = 180;
//    I2C1->TRISE = 37;

//    I2C1->CR1  |= I2C_CR1_ACK;     // ACK ???????, ??? ????????
//    I2C1->CR1  |= I2C_CR1_PE;
//}


////void SystemClock_Config(void);  // ???? ??????? ?? CubeMX
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState       = RCC_HSE_ON;         // ?????!
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState       = RCC_HSI_ON;

  RCC_OscInitStruct.PLL.PLLState   = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource  = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL     = RCC_PLL_MUL9;       // 8*9 = 72 ???
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) Error_Handler();

  RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK|
                                     RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;      // 36 ??? (<=36)
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;      // 72 ???

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) Error_Handler();

  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USB;
  PeriphClkInit.UsbClockSelection    = RCC_USBCLKSOURCE_PLL_DIV1_5; // 72/1.5=48
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK) Error_Handler();

  SystemCoreClockUpdate();
}
//int main(void)
//{
//  // 1) ??????? ???????? ?? 0x08005000 (Maple)
//  SCB->VTOR = FLASH_BASE + 0x5000U;
//  __DSB(); __ISB();

//  // 2) ??????? ???????????? GPIOB ? ???????? PB2 ??? output (?????????)
//  RCC->APB2ENR |= RCC_APB2ENR_IOPBEN;
//  GPIOB->CRL &= ~(0xF << (2*4));
//  GPIOB->CRL |=  (0x2 << (2*4));      // PB2: push-pull 2 MHz

//  // ???????? ????-???????? ?? HAL � 3 ??????? (?????, ??? ?? ?????????)
//  for (int i=0; i<3; i++) {
//    GPIOB->BSRR = (1U<<2);
//    for (volatile uint32_t d=0; d<400000; ++d) __NOP();
//    GPIOB->BRR  = (1U<<2);
//    for (volatile uint32_t d=0; d<400000; ++d) __NOP();
//  }

//  // 3) HAL + ????????? ???? (72 MHz, USB = 48 MHz)
//  HAL_Init();
//  SystemClock_Config();              // ?????? ?????? SYS=72, USB=48

//  // 4) ???????? ????? USB ? �??????????� D+ (????? ?? ????????????? ??????????)
//  RCC->APB2ENR |= RCC_APB2ENR_IOPAEN;

//  // 4.1) PA12 ???????? � GPIO PP, ? 0
//  GPIOA->CRH &= ~(0xF << ((12-8)*4));
//  GPIOA->CRH |=  (0x1 << ((12-8)*4));   // 10 MHz push-pull
//  GPIOA->BRR  =  (1U << 12);            // D+ = 0
//  // 10�15 ?? ????? (??? 72 ??? 720000 ~ 10 ??)
//  for (volatile uint32_t i=0; i<720000; ++i) __NOP();

//  // 4.2) ??????? PA12 ? ????? USB (AF push-pull)
//  GPIOA->CRH &= ~(0xF << ((12-8)*4));
//  GPIOA->CRH |=  (0xB << ((12-8)*4));   // AF push-pull (USB)

//  // 4.3) ???????? USB-?????????
//  RCC->APB1RSTR |=  RCC_APB1RSTR_USBRST;
//  for (volatile uint32_t i=0; i<2000; ++i) __NOP();
//  RCC->APB1RSTR &= ~RCC_APB1RSTR_USBRST;

//  // 5) ????????????? GPIO ?? Cube (???? ???????????) ? USB CDC
//  MX_GPIO_Init();

//  MX_USB_DEVICE_Init();
//	i2c1_init();
//HAL_Delay(15);
//ssd1306_Init();
//ssd1306_Fill(Black);
//ssd1306_WriteString("USB OK", Font_7x10, White);
//ssd1306_UpdateScreen();
//  // 6) ???????? ????-????: ?????? PB2 ? ???? ??????? ?? CDC
//  uint32_t t_led = HAL_GetTick();
//  uint32_t t_msg = HAL_GetTick();

//  for (;;)
//  {
//    if ((int32_t)(HAL_GetTick() - t_led) >= 250) {
//      GPIOB->ODR ^= (1U<<2);      // ???????
//      t_led += 250;
//    }

//    if ((int32_t)(HAL_GetTick() - t_msg) >= 1000) {
//      char buf[96];
//      snprintf(buf, sizeof(buf),
//               "SYS=%lu HCLK=%lu P1=%lu P2=%lu\r\n",
//               HAL_RCC_GetSysClockFreq(),
//               HAL_RCC_GetHCLKFreq(),
//               HAL_RCC_GetPCLK1Freq(),
//               HAL_RCC_GetPCLK2Freq());
//      CDC_Puts(buf);              // ?????? ? ?????????
//      t_msg += 1000;
//    }
//  
//	// <<< ??? >>>
//    int ch = CDC_Read_Byte();     // ?????? -1 ???? ?????? ???
//    if (ch >= 0) {
//        CDC_Send_Byte((uint8_t)ch);
//        // ?? ???????: ???? ????? ??????? ??????, ??????????????
//        // if (ch == '\r') CDC_Send_Byte('\n');
//    }
//	}
//}
int main(void)
{
  // VTOR ?? 0x08005000
  SCB->VTOR = FLASH_BASE + 0x5000U; __DSB(); __ISB();

  // ??????? PB2 ?? HAL � ??? ? ????
//  RCC->APB2ENR |= RCC_APB2ENR_IOPBEN;
//  GPIOB->CRL &= ~(0xF << (2*4));
//  GPIOB->CRL |=  (0x2 << (2*4));
//  for (int i=0; i<3; i++){ GPIOB->BSRR=(1U<<2); for(volatile uint32_t d=0; d<400000; d++)__NOP(); GPIOB->BRR=(1U<<2); for(volatile uint32_t d=0; d<400000; d++)__NOP(); }

  HAL_Init();
  SystemClock_Config();     // ? ???? ??? ??: HSE*9=72, USB=48

  // USB �???????? ?????� ?? PA12 � ??? ? ????
  RCC->APB2ENR |= RCC_APB2ENR_IOPAEN;
  GPIOA->CRH &= ~(0xF << ((12 - 8) * 4));
  GPIOA->CRH |=  (0x1 << ((12 - 8) * 4));
  GPIOA->BRR  =  (1U << 12);
  for (volatile uint32_t i=0; i<720000; ++i) __NOP();
  GPIOA->CRH &= ~(0xF << ((12 - 8) * 4));
  GPIOA->CRH |=  (0xB << ((12 - 8) * 4));
  RCC->APB1RSTR |=  RCC_APB1RSTR_USBRST; for (volatile uint32_t i=0; i<2000; ++i) __NOP();
  RCC->APB1RSTR &= ~RCC_APB1RSTR_USBRST;

  MX_GPIO_Init();
  MX_USB_DEVICE_Init();

  // >>> ??? ???
  App_Init();

  while (1) {
    App_Loop();
  }
}