#ifndef __SSD1306_CONF_H__
#define __SSD1306_CONF_H__


#define STM32F1


#define SSD1306_USE_I2C


#define SSD1306_I2C_ADDR        0x3C

#define SSD1306_I2C_SCL_Port    GPIOB
#define SSD1306_I2C_SCL_Pin     GPIO_Pin_6

#define SSD1306_I2C_SDA_Port    GPIOB
#define SSD1306_I2C_SDA_Pin     GPIO_Pin_7

#define SSD1306_INCLUDE_FONT_6x8
#define SSD1306_INCLUDE_FONT_7x10
#define SSD1306_INCLUDE_FONT_11x18
#define SSD1306_INCLUDE_FONT_16x26

#endif /* __SSD1306_CONF_H__ */
