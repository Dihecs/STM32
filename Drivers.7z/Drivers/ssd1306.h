#ifndef __SSD1306_H__
#define __SSD1306_H__

#include <stdint.h>
#include <stddef.h>
#include "ssd1306_conf.h"

#define SSD1306_I2C_ADDR     (0x3C << 1)  // ????? ??????? 0x3C (????? ??? I2C 7-??? -> 8-???)

#define SSD1306_WIDTH        128
#define SSD1306_HEIGHT       64
#define SSD1306_BUFFER_SIZE  (SSD1306_WIDTH * SSD1306_HEIGHT / 8)

// === ????? ===
typedef enum {
    Black = 0x00,
    White = 0x01
} SSD1306_COLOR;

// === ?????? ===
typedef enum {
    SSD1306_OK = 0x00,
    SSD1306_ERR = 0x01
} SSD1306_Error_t;

// === ?????????? ===
typedef struct {
    uint16_t CurrentX;
    uint16_t CurrentY;
    uint8_t Initialized;
    uint8_t DisplayOn;
} SSD1306_t;

// === ??????? (?????) ===
typedef struct {
    uint8_t x;
    uint8_t y;
} SSD1306_VERTEX;

// === ????????? ?????? ===
typedef struct {
    const uint8_t width;
    const uint8_t height;
    const uint16_t *const data;
    const uint8_t *const char_width;
} SSD1306_Font_t;

// === ???????? ??????? ===
void ssd1306_Init(void);
void ssd1306_Fill(SSD1306_COLOR color);
void ssd1306_UpdateScreen(void);
void ssd1306_DrawPixel(uint8_t x, uint8_t y, SSD1306_COLOR color);
char ssd1306_WriteChar(char ch, SSD1306_Font_t Font, SSD1306_COLOR color);
char ssd1306_WriteString(char* str, SSD1306_Font_t Font, SSD1306_COLOR color);
void ssd1306_SetCursor(uint8_t x, uint8_t y);

// === ????????? ===
void ssd1306_Line(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, SSD1306_COLOR color);
void ssd1306_DrawCircle(uint8_t x0, uint8_t y0, uint8_t r, SSD1306_COLOR color);
void ssd1306_FillCircle(uint8_t x0, uint8_t y0, uint8_t r, SSD1306_COLOR color);
void ssd1306_DrawRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, SSD1306_COLOR color);
void ssd1306_FillRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, SSD1306_COLOR color);
SSD1306_Error_t ssd1306_InvertRectangle(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2);

// === ?????????????? ??????? � ?????????? ?? .c ??????? ????? I2C1 ===
void ssd1306_WriteCommand(uint8_t byte);
void ssd1306_WriteData(uint8_t* buffer, size_t buff_size);

#endif // __SSD1306_H__
